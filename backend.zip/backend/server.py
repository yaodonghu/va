import argparse
import collections
import datetime
import flask
import lab_learner
import matplotlib.pyplot as plt
import numpy as np
import os
import pickle
import random
import re
import traceback
import urllib
from flask_cors import CORS
import simplejson

p = argparse.ArgumentParser(description="""
Start adjudication server.

Example if starting from scratch:
$ ipython -i server.py -- --csv ../test_data/simulated_data.csv --pickle ./test.pickle

Example if continuing from previously:
$ ipython -i server.py -- --pickle ./test.pickle
""", formatter_class=argparse.RawTextHelpFormatter)
p.add_argument("--port", default=3000, type=int,
                         help="Port to run the tool on.")
p.add_argument("--csv", help="The CSV file to adjudicate. Only provide "
                             "this if you're starting from scratch.")
p.add_argument("--pickle", help="The pickle file to read and write "
                                "adjudication results from. If you "
                                "specify a CSV file to adjudicate, "
                                "then this pickle file shouldn't exist "
                                "(we don't want to accidentally "
                                "overwrite previous results).")
p.add_argument("--log", help="The log file where interactions are recorded.")
args = p.parse_args()

print("Running with args", args)
if args.csv is not None:
  assert not os.path.exists(args.pickle), \
    "Don't specify a CSV file if you specify a pickle file that " \
    "already exists."
if args.csv is None:
  assert args.pickle is not None, \
    "If you don't specify a CSV file, you need to specify a " \
    "pickle file."

def now():
  return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")

class UIState:
  def __init__(self):
    self.set_sort("tb", "RowID", "asc")
  def set_sort(self, table, column, sort_dir):
    self.sort_table = table
    self.sort_column = column
    self.sort_dir = sort_dir

app = flask.Flask(__name__)
CORS(app)
app.config["JSONIFY_PRETTYPRINT_REGULAR"] = False
ui_state = UIState()
if args.csv is not None:
  learner = lab_learner.Learner(args.csv)
  learner.add_percentile_feature()
  learner.add_numerical_feature("n")
  learner.add_numerical_feature("min")
  learner.add_numerical_feature("p1")
  learner.add_numerical_feature("p5")
  learner.add_numerical_feature("p10")
  learner.add_numerical_feature("p25")
  learner.add_numerical_feature("p50")
  learner.add_numerical_feature("p75")
  learner.add_numerical_feature("p90")
  learner.add_numerical_feature("p95")
  learner.add_numerical_feature("p99")
  learner.add_numerical_feature("max")
  learner.add_bow_features("TestName")
  learner.add_bow_features("Component")
  learner.add_bow_features("Topography")
  #learner.add_bow_features("Specimen")
  #learner.add_categorical_feature("VISN")
  #learner.add_categorical_feature("Sta3n")
  learner.add_categorical_feature("Units")
  learner.add_categorical_feature("LOINC")
  learner.update_model()
else:
  learner = pickle.load(open(args.pickle, "rb"))

def get_argsort():
  table = ui_state.sort_table
  column = ui_state.sort_column
  sort_dir= ui_state.sort_dir

  if table == "ft":
    idxs = np.where(learner.ft_names == column)[0]
    assert len(idxs) >= 1, "No column in {} matches {}".format(learner.ft_names, column)
    if len(idxs) != 1:
      print("Warning: len(idxs) != 1 in set_sort. Bug?")
    i = idxs[0]
    arg = list(np.argsort(learner.ft_matrix[:,i]))
  elif table == "tb":
    arg = list(np.argsort(learner.tb[column]))
  elif table == "pl":
    if column == "pred":
      arg = list(np.argsort(learner.pred_labels))
    elif column == "p(yes)":
      arg = list(np.argsort(learner.pred_probs))
    elif column == "margin":
      arg = list(np.argsort(learner.pred_margin))
    else:
      assert False, "unknown column in pl: %s" % column
  elif table == "ul":
    if column == "user":
      arg = list(np.argsort(learner.user_labels))
    else:
      assert False, "unknown column in ul: %s" % column
  else:
      assert False, "unknown table: %s" % table

  arg = np.array(arg)
  if sort_dir == "asc":
    pass
  elif sort_dir == "desc":
    arg = arg[::-1]
  else:
    assert False, "unknown sort_dir: %s" % sort_dir

  return arg

def make_display_labels(labels):
  disp = labels.astype("str")
  disp[disp == "nan"] = "-"
  disp[disp == "0.0"] = "no"
  disp[disp == "1.0"] = "yes"
  return disp

# Make fake data for column headers, based on preserialized data. This
# is a hack in that we shouldn't be using this data structure for the
# headers.
def make_header(preserialized_data):
  x = preserialized_data.copy()
  x["values"] = {c: [c] for c in x["columnNames"]}
  x["rowCount"] = 1
  return x

def preserialize_tb(argsort):
  column_names = learner.tb.columns.tolist()
  row_count = learner.tb.shape[0]
  assert len(argsort) == row_count

  sorted_tb = learner.tb.iloc[argsort,:]
  rounded_tb = sorted_tb.copy()
  for c in learner.tb.columns[learner.tb.dtypes == "float64"]:
    rounded_tb[c] = np.round(rounded_tb[c], 1)

  column_widths = {c: 60 for c in column_names}
  column_widths["RowID"] = 70
  column_widths["TestSID"] = 70
  column_widths["TestName"] = 100
  column_widths["Topography"] = 100
  #column_widths["Specimen"] = 150
  column_widths["Units"] = 70

  return {
    "columnNames": column_names,
    "columnWidths": column_widths,
    "values": rounded_tb.to_dict(orient="list"),
    "rowCount": row_count
  }

def preserialize_ft(argsort):
  column_names = list(learner.ft_names)
  row_count = learner.ft_matrix.shape[0]
  assert len(argsort) == row_count
  sorted_matrix = learner.ft_matrix[argsort,:]
  rounded_matrix = np.round(sorted_matrix, 1)
  values = {c: rounded_matrix[:,i].tolist()
            for i, c in enumerate(column_names)}
  column_widths = {c: 100 for c in column_names}
  return {
    "columnNames": column_names,
    "columnWidths": column_widths,
    "values": values,
    "rowCount": row_count
  }

def preserialize_ul(argsort):
  row_count = len(learner.user_labels)
  assert len(argsort) == row_count
  sorted_user_labels = learner.user_labels[argsort]
  x = make_display_labels(sorted_user_labels).tolist()
  return {
    "columnNames": ["user"],
    "columnWidths": {"user": 75},
    "values": {"user": x},
    "rowCount": row_count
  }

def preserialize_pl(argsort):
  row_count = len(argsort)
  assert len(learner.pred_probs) == row_count
  assert len(learner.pred_labels) == row_count
  assert len(learner.pred_margin) == row_count

  sorted_pred_probs = learner.pred_probs[argsort]
  sorted_pred_labels = learner.pred_labels[argsort]
  sorted_pred_margin = learner.pred_margin[argsort]

  x = np.round(sorted_pred_probs*100, 0).tolist()
  x = ["-" if np.isnan(xi) else "%0.0f%%"  % xi for xi in x]
  y = make_display_labels(sorted_pred_labels).tolist()
  z = np.round(sorted_pred_margin*100, 0).tolist()
  z = ["-" if np.isnan(zi) else "%0.0f%%"  % zi for zi in z]

  return {
    "columnNames": ["p(yes)", "margin", "pred"],
    "columnWidths": {"p(yes)": 60, "margin": 60, "pred": 60},
    "values": {"p(yes)": x, "margin": z, "pred": y},
    "rowCount": row_count
  }

def preserialize_stats():
  y = np.round(learner.coefs, 2).tolist()
  coefs = dict(zip(learner.ft_names, y))
  return {
    "trainPrecision": round(100*learner.train_precision, 0),
    "trainRecall": round(100*learner.train_recall, 0),
    "trainAccuracy": round(100*learner.train_accuracy, 0),
    "ftCoefs": coefs
  }

def preserialize_sort():
  return {
    "tableName": ui_state.sort_table,
    "columnName": ui_state.sort_column,
    "sortDir": ui_state.sort_dir
  }

def update_and_save_model():
  # Update model.
  print(now(), "Begin update model")
  try:
    learner.update_model()
  except:
    print("Couldn't update model. The error was:")
    traceback.print_exc()
  print(now(), "End update model")

  # Save model.
  print(now(), "Begin save model")
  with open(args.pickle, "wb") as fo:
    pickle.dump(learner, file=fo)
  print(now(), "End save model")

def preserialize_updateModel():
  update_and_save_model()

  # Preserialize everything and return it.
  argsort = get_argsort()
  p_ft = preserialize_ft(argsort)
  p_tb = preserialize_tb(argsort)
  p_ul = preserialize_ul(argsort)
  p_pl = preserialize_pl(argsort)
  if False:
    print("--------------------")
    print("argsort", argsort[:5])
    for k, v in p_ft["values"].items(): print("ft", k, v[:5])
    for k, v in p_tb["values"].items(): print("tb", k, v[:5])
    for k, v in p_ul["values"].items(): print("ul", k, v[:5])
    for k, v in p_pl["values"].items(): print("pl", k, v[:5])
    print("ul yes:", [i for i, v in enumerate(p_ul["values"]["user"]) if v == "yes"])
    print("ul no:", [i for i, v in enumerate(p_ul["values"]["user"]) if v == "no"])
    print("--------------------")
  return simplejson.dumps({"tb": p_tb,
          "ft": p_ft,
          "ul": p_ul,
          "pl": p_pl,
          "tbHeader": make_header(p_tb),
          "ftHeader": make_header(p_ft),
          "ulHeader": make_header(p_ul),
          "plHeader": make_header(p_pl),
          "stats": preserialize_stats(),
          "sort": preserialize_sort()},ignore_nan=True,default=datetime.datetime.isoformat)

def log(path, the_args):
  now = datetime.datetime.now()
  encoded_args = urllib.parse.urlencode(the_args)
  with open(args.log, "a") as fo:
    print("{},{},{}".format(now, path, encoded_args), file=fo)


@app.route("/api/everything")
def api_everything():
  log("everything", {})
  response = app.response_class(
        response=preserialize_updateModel(),
        status=200,
        mimetype='application/json'
    )
  return response
  # return flask.jsonify(preserialize_updateModel())

@app.route("/api/oldLabelExample", methods=["POST"])
def api_oldlabel():
  args = flask.request.get_json()
  log("oldLabelExample", args)
  oldLabel = args["oldLabel"]
  rowIndex = int(args["rowIndex"])
  if oldLabel == "no":
    newValue = 1.0
  else:
    newValue = 0.0
  learner.label_example(rowIndex, newValue)
  return flask.jsonify(preserialize_updateModel())

@app.route("/api/labelExample", methods=["POST"])
def api_label():
  args = flask.request.get_json()
  log("labelExample", args)
  new_label = args["newLabel"]
  row_index_in_displayed = int(args["rowIndex"])

  argsort = get_argsort()
  indices_of_original_table = np.array(range(len(argsort)))
  indices_of_displayed_table = indices_of_original_table[argsort]
  row_index_in_original = indices_of_displayed_table[row_index_in_displayed]

  if new_label == "yes":
    new_value = 1.0
  elif new_label == "no":
    new_value = 0.0
  else:
    new_value = np.NAN

  learner.label_example(row_index_in_original, new_value)
  return flask.jsonify(preserialize_updateModel())

@app.route("/api/addCategoricalFeature", methods=["POST"])
def api_addCategoricalFeature():
  args = flask.request.get_json()
  log("addCategoricalFeature", args)
  column = args["column"]
  learner.add_categorical_feature(column)
  return flask.jsonify(preserialize_updateModel())

@app.route("/api/addCountFeature", methods=["POST"])
def api_addCountFeature():
  args = flask.request.get_json()
  log("addCountFeature", args)
  column = args["column"]
  pattern = args["pattern"]
  learner.add_regex_count_feature(column, pattern)
  return flask.jsonify(preserialize_updateModel())

@app.route("/api/addBOWFeatures", methods=["POST"])
def api_addBOWFeatures():
  args = flask.request.get_json()
  log("addBOWFeatures", args)
  column = args["column"]
  learner.add_bow_features(column)
  return flask.jsonify(preserialize_updateModel())

@app.route("/api/removeFeatureByName", methods=["POST"])
def api_removeFeatureByName():
  args = flask.request.get_json()
  log("removeFeatureByName", args)
  featureName = args["featureName"]
  learner.ft.remove_by_name(featureName)
  return flask.jsonify(preserialize_updateModel())

@app.route("/api/removeFeaturesByCategory", methods=["POST"])
def api_removeFeaturesByCategory():
  args = flask.request.get_json()
  log("removeFeaturesByCategory", args)
  categoryName = args["categoryName"]
  learner.ft.remove_by_category(categoryName)
  return flask.jsonify(preserialize_updateModel())

@app.route("/api/removeFeaturesBySourceColumn", methods=["POST"])
def api_removeFeaturesBySourceColumn():
  args = flask.request.get_json()
  log("removeFeaturesBySourceColumn", args)
  sourceColumn = args["sourceColumn"]
  learner.ft.remove_by_source_column(sourceColumn)
  return flask.jsonify(preserialize_updateModel())

@app.route("/api/setSort", methods=["POST"])
def api_setSort():
  args = flask.request.get_json()
  log("setSort", args)
  tableName = args["tableName"]
  columnName = args["columnName"]
  sortDir = args["sortDir"]
  ui_state.set_sort(tableName, columnName, sortDir)
  return flask.jsonify(preserialize_updateModel())

@app.route("/react_app", defaults={"path": "index.html"})
@app.route("/react_app/<path:path>")
def send_react_app(path):
  return flask.send_from_directory("../frontend/build", path)

@app.route("/datatables_app", defaults={"path": "index.html"})
@app.route("/datatables_app/<path:path>")
def send_datatables_app(path):
  return flask.send_from_directory("../datatables_app", path)

@app.route("/datatables_label_examples", methods=["POST"])
def datatables_label_examples():
  new_label = flask.request.form["label"]
  row_ids_str = flask.request.form["row_ids"]
  row_ids = [int(i) for i in row_ids_str.split(",")]
  log("datatables_label_examples", {"label": new_label, "row_ids": row_ids_str})

  if new_label == "yes":
    new_value = 1.0
  elif new_label == "no":
    new_value = 0.0
  else:
    new_value = np.NAN

  print(now(), "Begin labelling")
  for row_id in row_ids:
    row_index = np.where(learner.tb.RowID == row_id)[0]
    learner.label_example(row_index, new_value)
  print(now(), "End labelling")

  update_and_save_model()
  return flask.jsonify({})

@app.route("/datatables_data_head", methods=["GET"])
def send_datatables_data_head():
  colnames = (["User", "Pred", "P(yes)", "Margin"] +
              [colname for colname in learner.tb.columns])
  return flask.jsonify(colnames)

def _parse_datatables_data_columns(args):
  """
  ImmutableMultiDict([
    ('start', '0'),
    ('length', '10'),
    ('search[value]', ''),
    ('search[regex]', 'false'),
    ('order[0][dir]', 'asc'),
    ('_', '1502485954278'),
    ('order[0][column]', '0'),
    ('draw', '1'),

    ('columns[4][orderable]', 'true'),
    ('columns[4][name]', ''),
    ('columns[4][data]', '4'),
    ('columns[4][search][value]', ''),
    ('columns[4][search][regex]', 'false'),
    ('columns[4][searchable]', 'true'),

    [...]
  ])
  """

  columns = {}
  pattern = r"^columns\[([0-9]+)\]"
  for k, v in args.items():
    res = re.search(pattern, k)
    if res is not None:
      index = int(res.groups()[0])
      key = re.sub(pattern, "", k)
      if index not in columns:
        columns[index] = {}
      columns[index][key] = v
  columns_list = [columns[i] for i in range(len(columns))]
  return columns_list

def _parse_datatables_data_order(args):
  """Parse, e.g., the following:
    ('order[0][column]', '7'),
    ('order[0][dir]', 'asc'),
    ('order[1][column]', '3'),
    ('order[1][dir]', 'desc'),
    ('order[2][column]', '5'),
    ('order[2][dir]', 'asc'),
  """

  order = {}
  pattern = r"^order\[([0-9]+)\]"
  for k, v in args.items():
    res = re.search(pattern, k)
    if res is not None:
      index = int(res.groups()[0])
      key = re.sub(pattern, "", k)
      if index not in order:
        order[index] = {}
      order[index][key] = v
  order_list = [order[i] for i in range(len(order))]
  return order_list

@app.route("/datatables_data", methods=["GET"])
def send_datatables_data():
  args = flask.request.args
  #print(args)

  draw = int(args["draw"])
  start = int(args["start"])
  length = int(args["length"])
  args_columns = _parse_datatables_data_columns(args)
  order = _parse_datatables_data_order(args)
  #print(args_columns)
  #print(order)

  def make_link(test_sid, new_label, current_label):
    return ("<a href='javascript:label_example(%d, \"%s\")'>%s</a>" % (test_sid, new_label, new_label))

  def make_links(test_sid, current_label):
    links = []
    for label in ["yes", "no", "-"]:
      if current_label == label:
        links.append(label)
      else:
        links.append(make_link(test_sid, label, current_label))
    return "&nbsp;".join(links)

  print(now(), "Make starting_tb")
  starting_tb = learner.tb.copy()
  #starting_tb.insert(1, "Pred", ["<a href='javascript:void(0)'>%s</a>" % l for l in make_display_labels(learner.pred_labels))]
  starting_tb.insert(0, "P(yes)", learner.pred_probs)
  starting_tb.insert(1, "Margin", learner.pred_margin)
  starting_tb.insert(2, "Pred", make_display_labels(learner.pred_labels))
  #starting_tb.insert(3, "User", make_display_labels(learner.user_labels))
  starting_tb.insert(3, "User", [make_links(sid, l) for sid, l in zip(learner.tb.RowID, make_display_labels(learner.user_labels))])
  starting_columns = starting_tb.columns
  starting_row_count = starting_tb.shape[0]
  print("starting_tb.shape", starting_tb.shape)

  print(now(), "Make sorted_tb")
  order_column_indices = [int(o["[column]"]) for o in order]
  order_column_names = [starting_columns[i] for i in order_column_indices]
  order_ascendings = [o["[dir]"] == "asc" for o in order]
  sorted_tb = starting_tb.sort_values(order_column_names, ascending=order_ascendings)
  print("sorted_tb.shape", sorted_tb.shape)

  print(now(), "Make rounded_tb")
  rounded_tb = sorted_tb.copy()
  rounded_tb["Margin"] = np.round(rounded_tb.Margin, 2).astype("str")
  rounded_tb["P(yes)"] = np.round(rounded_tb["P(yes)"], 2).astype("str")
  for c in rounded_tb.columns[rounded_tb.dtypes == "float64"]:
    rounded_tb[c] = np.round(rounded_tb[c], 1).astype("str")
  print("rounded_tb.shape", rounded_tb.shape)

  print(now(), "Make filtered_tb")
  filtered_tb = rounded_tb
  print(args_columns)
  for i, column_info in enumerate(args_columns):
    val = column_info["[search][value]"]
    if val != "":
      colname = filtered_tb.columns[i]
      col = filtered_tb[colname]
      print("Filtering by", colname, "on", val)
      # if col.dtype == "int":
      #   filtered_tb = filtered_tb.ix[col == int(val),:]
      # elif col.dtype == "float":
      #   filtered_tb = filtered_tb.ix[col == float(val),:]
      # else:
      #   #filtered_tb = filtered_tb.ix[col.str.find(val) != -1,:]
      #   filtered_tb = filtered_tb.ix[col.str.contains(val),:]
      filtered_tb = filtered_tb.ix[col.str.lower().str.contains(val.lower()),:]
  filtered_tb_row_count = filtered_tb.shape[0]
  print("filtered_tb.shape", filtered_tb.shape)

  print(now(), "Make sliced_tb")
  sliced_tb = filtered_tb.iloc[start:(start+length),:]
  print("sliced_tb.shape", sliced_tb.shape)

  print(now(), "Make data")
  data = sliced_tb.to_dict(orient="records")

  print(now(), "Make ret")
  ret = {"draw": draw,
         "recordsTotal": starting_row_count,
         "recordsFiltered": filtered_tb_row_count,
         "data": data}
  print(now(), "Done")
  return flask.jsonify(ret)

@app.route("/datatables_stats", methods=["GET"])
def send_datatables_stats():
  args = flask.request.args
  stats = preserialize_stats();
  return flask.jsonify(stats);

@app.route("/datatables_ft", methods=["GET"])
def send_datatables_ft():
  args = flask.request.args
  y = np.round(learner.coefs, 2).tolist()
  coefs = list(zip(learner.ft_names, y))
  coefs.sort(key=lambda x: -abs(x[1])) # sort desc by abs value
  ret = {"ftCoefs": coefs}
  return flask.jsonify(ret)

app.run(debug=True, port=args.port, host='0.0.0.0')
