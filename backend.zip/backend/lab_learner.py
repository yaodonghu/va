import collections
import numpy as np
import pandas as pd
import re
import sklearn
import sklearn.ensemble
import sklearn.feature_extraction
import sklearn.linear_model
import sklearn.metrics
import sklearn.pipeline
import traceback

class CategoricalBinarizer(sklearn.base.BaseEstimator,
                           sklearn.base.TransformerMixin):
  """This class constructs categorical features from the columns of x.
  """
  def __init__(self):
    pass
  def fit(self, x, y=None):
    self.classes = list(np.unique(x))
    self.classes_dict = {c: i for (i, c) in enumerate(self.classes)}
    return self
  def transform(self, x):
    assert len(x.shape) == 1
    num_examples = x.shape[0]
    num_classes = len(self.classes)
    z = np.zeros((num_examples, num_classes))
    for i in range(num_examples):
      xi = x.values[i]
      if xi in self.classes_dict:
        j = self.classes_dict[xi]
        z[i,j] = 1
    return z
  def get_feature_names(self):
    return self.classes

class ColumnSelector(sklearn.base.BaseEstimator,
                     sklearn.base.TransformerMixin):
  """This class selects the column/columns of the data frame (given to
  transform) that matches the column name/names (given to __init__). This is
  adapted from the sklearn documentation's "Feature Union with Heterogeneous
  Data Sources" example.
  """
  def __init__(self, column_name_or_names):
    self.column_name_or_names = column_name_or_names
  def fit(self, x, y=None):
    return self
  def transform(self, the_data_frame):
    return the_data_frame.ix[:,self.column_name_or_names]

class ConvertToMatrix(sklearn.base.BaseEstimator,
                      sklearn.base.TransformerMixin):
  """Define a class to convert the given length-n vector to an n-by-1 matrix,
  which is what sklearn expects.
  """
  def __init__(self):
    pass
  def fit(self, x, y=None):
    return self
  def transform(self, the_column):
    z = np.copy(the_column)
    assert len(z.shape) == 1
    z.shape = (z.shape[0], 1)
    self._feature_names = [the_column.name]
    return z
  def get_feature_names(self):
    return self._feature_names

class FeaturePipeline(sklearn.pipeline.Pipeline):
  """Define a Pipeline class that has the get_feature_names method. This is
  from pull request #2007 on scikit-learn's github page.
  """
  def get_feature_names(self):
    name, trans = self.steps[-1]
    if not hasattr(trans, 'get_feature_names'):
      raise AttributeError("Transformer %s does not provide"
                           " get_feature_names." % str(name))
    return trans.get_feature_names()

class PercentileFeatureEncoder(sklearn.base.BaseEstimator,
                               sklearn.base.TransformerMixin):
  """Define a class that adds features that compare the distribution of the
  example to the distribution of the "yes" training examples.
  """
  def __init__(self, percentile_column_names):
    self.percentile_column_names = percentile_column_names
  def fit(self, x, y):
    positive_x = x.ix[y == 1,:]
    total_n = np.sum(positive_x["n"])
    if total_n == 0:
      self.total_n_is_zero = True
      return self
    self.total_n_is_zero = False
    weight_vec = positive_x["n"]/total_n
    perct_mat = positive_x.ix[:,self.percentile_column_names].values
    self.positive_percentiles = np.dot(weight_vec, perct_mat)
    return self
  def transform(self, x):
    stats = np.zeros((x.shape[0], 1))
    if not self.total_n_is_zero:
      x_percentiles = x.ix[:,self.percentile_column_names].values
      for i in range(x.shape[0]):
        stats[i,0] = np.max(np.abs(self.positive_percentiles - x_percentiles[i,:]))
    self._feature_names = ["ks_stat"]
    return stats
  def get_feature_names(self):
    return self._feature_names

class ToDense(sklearn.base.BaseEstimator, sklearn.base.TransformerMixin):
  """Define a class that converts a sparse matrix to a dense one. Our matrices
  are small enough that this is ok.
  """
  def __init__(self):
    pass
  def fit(self, x, y=None):
    return self
  def transform(self, x):
    return x.todense()


FeatureSpec = collections.namedtuple("FeatureSpec",
                                     ["column", "ftype", "args"])

class FeaturePipelineConstructor:
  """This class builds up a sklearn pipeline from a linear list of features.
  The point here is that we can serialize a simple list of names and then
  later reconstitute the pipeline.
  """

  def __init__(self):
    self.feature_list = []

  def add_feature(self, column, ftype, args=None):
    self.feature_list.append(FeatureSpec(column, ftype, args))

  def remove_feature(self, index):
    del self.feature_list[index]

  def make_pipeline(self):
    feature_pipeline = sklearn.pipeline.FeatureUnion(
      transformer_list=[
        (feature_spec.column, self._make_transformer(feature_spec))
        for feature_spec in self.feature_list
      ])
    return feature_pipeline

  def _make_transformer(self, feature_spec):
    if feature_spec.ftype == "bow":
      return self._make_add_bow(feature_spec.column)
    elif feature_spec.ftype == "categorical":
      return self._make_add_categorical(feature_spec.column)
    elif feature_spec.ftype == "numerical":
      return self._make_add_numerical(feature_spec.column)
    elif feature_spec.ftype == "percentile":
      return self._make_add_percentile()
    elif feature_spec.ftype == "regex_count":
      return self._make_add_regex_count(feature_spec.column, feature_spec.args)
    else:
      raise RuntimeError("Unknown feature_spec.ftype: " + feature_spec.ftype)

  def _make_add_bow(self, column):
    return FeaturePipeline([
        ("selector", ColumnSelector(column)),
        ("bow", sklearn.feature_extraction.text.CountVectorizer())
      ])

  def _make_add_categorical(self, column):
    return FeaturePipeline([
        ("selector", ColumnSelector(column)),
        ("categorical", CategoricalBinarizer()),
      ])

  def _make_add_numerical(self, column):
    return FeaturePipeline([
        ("selector", ColumnSelector(column)),
        ("matrix", ConvertToMatrix()),
      ])

  def _make_add_percentile(self, percentile_columns=['p1', 'p5', 'p10', 'p25',
                                                     'p50', 'p75', 'p90',
                                                     'p95', 'p99']):
    return FeaturePipeline([
        ("selector", ColumnSelector(["n"] + percentile_columns)),
        ("percentile", PercentileFeatureEncoder(percentile_columns)),
      ])

class PipelineConstructor:
  def __init__(self):
    pass
  def make_pipeline(self, feature_pipeline):
    pipeline = sklearn.pipeline.Pipeline([
      ('union', feature_pipeline),
      ('imputer', sklearn.preprocessing.Imputer()),
      ('to_dense', ToDense()),
      ('standard', sklearn.preprocessing.StandardScaler()),
      ('lr', sklearn.linear_model.LogisticRegression(penalty="l1", tol=0.01)), # good
      #('lr', sklearn.linear_model.LogisticRegression())
      #('lr', sklearn.svm.SVC())
      #('lr', sklearn.ensemble.RandomForestClassifier()) # good ~97% cv accuracy
      #('lr', sklearn.ensemble.GradientBoostingClassifier()) # good ~97% cv accuracy
      #('lr', sklearn.linear_model.Lasso(normalize=True)) # doesn't work
      #('lr', sklearn.linear_model.LogisticRegressionCV()) # ~89% cv accuracy
      #('lr', sklearn.linear_model.LogisticRegressionCV(penalty="l1", solver="liblinear")) # super slow, doesn't seem much better than LogisticRegression with l1, tol=0.01
    ])
    return pipeline


class FeatureMatrix:
  """
  - Each column of `self.matrix` stores the corresponding feature values.
  - `self.names` contains the features' names.
  - `self.categories` contains the features' categories.
  - `self.sources` contains the features' source column names.
  """

  def __init__(self, matrix, names, sources):
    assert(matrix.shape[1] == len(names))
    self.matrix = matrix
    self.names = np.array(names)
    self.categories = np.array(["init" for i in self.names])
    self.sources = np.array(sources)

  def add(self, matrix, names, categories, sources):
    num_new_features = matrix.shape[1]
    assert len(names) == num_new_features
    assert len(categories) == num_new_features
    assert len(sources) == num_new_features
    print(type(self.matrix), self.matrix.dtype)
    self.matrix = np.concatenate((self.matrix, matrix), axis=1)
    self.matrix = np.asarray(self.matrix) # needed to serialize
    print(type(self.matrix), self.matrix.dtype)
    self.names = np.concatenate((self.names, names))
    self.categories = np.concatenate((self.categories, categories))
    self.sources = np.concatenate((self.sources, sources))

  def remove_by_indices(self, indices):
    self.matrix = np.delete(self.matrix, indices, axis=1)
    self.names = np.delete(self.names, indices)
    self.categories = np.delete(self.categories, indices)
    self.sources = np.delete(self.sources, indices)

  def remove_by_name(self, name):
    indices = [i for i, c in enumerate(self.names) if c == name]
    self.remove_by_indices(indices)

  def remove_by_category(self, category):
    indices = [i for i, c in enumerate(self.categories) if c == category]
    self.remove_by_indices(indices)
      
  def remove_by_source_column(self, source):
    indices = [i for i, c in enumerate(self.sources) if c == source]
    self.remove_by_indices(indices)

class Learner:
  def __init__(self, csv_filename, minimum_n=10):
    self.source_csv_filename = csv_filename
    self.read_tb(csv_filename, minimum_n)
    self.fpc = FeaturePipelineConstructor()
    self.pc = PipelineConstructor()

    #self.init_ft()
    self.init_labels()
    #self.init_model()
    #self.train_precision = 0
    #self.train_recall = 0
    #self.train_accuracy = 0

    #self.update_model()

  def read_tb(self, csv_filename, minimum_n):
    """Read the original data table."""
    dtypes = {"TrueLabel": str,
              "LabChemTestSID": np.int64,
              "LabChemTestName": str,
              "Topography": str,
              "Specimen": str,
              "VISN": str, #np.int64,
              "Sta3n": str, #np.int64,
              "Units": str,
              "n": np.int64,
              "min": np.float64,
              "p1": np.float64,
              "p5": np.float64,
              "p10": np.float64,
              "p25": np.float64,
              "p50": np.float64,
              "p75": np.float64,
              "p90": np.float64,
              "p95": np.float64,
              "p99": np.float64,
              "max": np.float64}
    # For the pulled data:
    self.tb = pd.read_csv(csv_filename, dtype=dtypes, index_col=0)
    # For the simulated test data:
    #self.tb = pd.read_csv(csv_filename, dtype=dtypes, index_col=0)
    # For the adjudicated examples:
    #self.tb = pd.read_csv(csv_filename, dtype=dtypes)
    ##self.tb = self.tb.drop("TrueLabel", 1)
    print(self.tb.columns)
    tmp = self.tb.columns.values

    # For the simulated test data:
    #assert tmp[0] == "LabChemTestSID"
    #assert tmp[1] == "LabChemTestName"
    #tmp[0] = "TestSID"
    #tmp[1] = "TestName"

    # For the adjudicated examples:
    #assert tmp[1] == "LabChemTestName"
    #tmp[1] = "TestName"
    #self.tb.columns = tmp
    #self.tb.insert(1, "TestSID", self.tb.index)

    # For the pulled data:
    assert tmp[0] == "LabChemTestSID"
    assert tmp[1] == "LabChemTestName"
    tmp[0] = "TestSID"
    tmp[1] = "TestName"
    self.tb.columns = tmp

    # # XXX hack to allow encoding Units as categorical
    #if "Units" in self.tb.columns:
    #  self.tb.ix[pd.isnull(self.tb.Units), "Units"] = "NA"
    # Remove all NAs. (XXX Do we want to do this here or just before display?)
    for c in self.tb.columns[self.tb.dtypes == "object"]:
      self.tb.ix[pd.isnull(self.tb[c]), c] = "NA"

    # Exclude rows with n < minimum_n
    self.tb = self.tb.ix[self.tb.n >= minimum_n,:]

    # Add index column.
    self.tb.insert(0, "RowID", range(self.tb.shape[0]))

  def init_ft(self):
    """Initialize the feature matrix data frame."""
    sub_tb = self.tb.select_dtypes(exclude=["object"])
    matrix = sub_tb.as_matrix()
    names = sub_tb.columns
    #sources = sub_tb.columns
    sources = ["-" for c in sub_tb.columns] # XXX hack
    assert matrix.dtype == np.float64
    self.ft = FeatureMatrix(matrix, names, sources)
    self.coefs = np.zeros(len(self.ft.names), dtype=np.float64)
    self.coefs[:] = 0.0

  def init_labels(self):
    self.user_labels = np.zeros(self.tb.shape[0], dtype=np.float64)
    self.pred_labels = np.zeros(self.tb.shape[0], dtype=np.float64)
    self.pred_probs = np.zeros(self.tb.shape[0], dtype=np.float64)
    self.pred_margin = np.zeros(self.tb.shape[0], dtype=np.float64)
    self.user_labels[:] = np.NAN
    self.pred_labels[:] = np.NAN
    self.pred_probs[:] = np.NAN
    self.pred_margin[:] = np.NAN

# def add_bow_features(self, column):
#   enc = sklearn.feature_extraction.text.CountVectorizer()
#   matrix = enc.fit_transform(self.tb[column]).todense()
#   num_features = matrix.shape[1]
#   #names = ["word_count(%s, %s)" % (word, column) for word in
#   names = ["%s ∋ %s" % (column, word) for word in
#            enc.get_feature_names()]
#   categories = ["word_count" for i in range(num_features)]
#   sources = [column for i in range(num_features)]
#   self.ft.add(matrix, names, categories, sources)

# def add_regex_count_feature(self, column, pattern):
#   matrix = np.array([[len(re.findall(pattern, s))] for s in
#                      self.tb[column]])
#   #names = ["regex_count(%s, %s)" % (pattern, column)]
#   names = ["%s ~ /%s/" % (column, pattern)]
#   categories = ["regex_count"]
#   sources = [column]
#   self.ft.add(matrix, names, categories, sources)

# def add_categorical_feature(self, column):
#   x = np.array(self.tb[column])
#   unique = np.unique(x)
#   matrix = np.zeros((len(x), len(unique)))
#   for i, n in enumerate(unique):
#     matrix[x == n,i] = 1
#   names = ["%s = %s" % (column, u) for u in unique]
#   categories = ["categorical" for u in unique]
#   sources = [column for u in unique]
#   self.ft.add(matrix, names, categories, sources)

  def add_bow_features(self, column):
    assert column in self.tb.columns
    self.fpc.add_feature(column, "bow")

  def add_categorical_feature(self, column):
    assert column in self.tb.columns
    self.fpc.add_feature(column, "categorical")

  def add_numerical_feature(self, column):
    assert column in self.tb.columns
    self.fpc.add_feature(column, "numerical")

  def add_percentile_feature(self):
    self.fpc.add_feature("percentile", "percentile")

  def add_regex_count_feature(self, column, pattern):
    assert column in self.tb.columns
    self.fpc.add_feature(column, "regex_count", pattern)

  def label_example(self, index, value):
    self.user_labels[index] = value

# def init_model(self):
#   self.model = sklearn.linear_model.LogisticRegression(penalty="l1",
#                                                        tol=0.01)

# def update_model(self):
#   # Extract labelled data and fit model.
#   has_label = (np.isnan(self.user_labels) == False)
#   train_matrix = self.ft.matrix[has_label,:]
#   train_labels = self.user_labels[has_label]
#   self.model.fit(train_matrix, train_labels)

#   # Compute predicted labels.
#   self.pred_labels = self.model.predict(self.ft.matrix)
#   proba = self.model.predict_proba(self.ft.matrix)
#   self.pred_probs = proba[:,1]
#   self.pred_margin = np.abs(proba[:,0] - proba[:,1])
#   print(self.pred_margin)

#   # Compute coefficients.
#   self.coefs = self.model.coef_[0,:]

#   # Compute accuracy etc.
#   train_pred = self.pred_labels[has_label]
#   self.train_precision = \
#     sklearn.metrics.precision_score(train_labels, train_pred)
#   self.train_recall = \
#     sklearn.metrics.recall_score(train_labels, train_pred)
#   self.train_accuracy = \
#     sklearn.metrics.accuracy_score(train_labels, train_pred)

  def update_model(self):
    # Setup pipeline.
    self.feature_pipeline = self.fpc.make_pipeline()
    self.pipeline = self.pc.make_pipeline(self.feature_pipeline)

    # Determine which examples have been labeled and how many of each class
    # have been labelled.
    has_label = (np.isnan(self.user_labels) == False)
    unique_labels = np.unique(self.user_labels[has_label])
    num_classes_labelled = len(unique_labels)

    if num_classes_labelled == 2:
      # Extract labelled data and fit model.
      train_tb = self.tb.ix[has_label,:]
      train_labels = self.user_labels[has_label]
      self.pipeline.fit(train_tb, train_labels)

      # Compute predicted labels.
      self.pred_labels = self.pipeline.predict(self.tb)
      proba = self.pipeline.predict_proba(self.tb)
      self.pred_probs = proba[:,1]
      self.pred_margin = np.abs(proba[:,0] - proba[:,1])
      print(self.pred_margin)

      # Extract the feature matrix Compute features for training data (for display only).
      feature_step = self.pipeline.named_steps["union"]
      self.ft_matrix = feature_step.transform(self.tb).todense()
      self.ft_names = feature_step.get_feature_names()

      # Compute coefficients.
      if not (
             self.pipeline.named_steps["union"].get_feature_names() == \
             self.ft_names
             ):
        print("Warning: features not right for the coefs")
      self.coefs = self.pipeline._final_estimator.coef_[0,:]

      # Compute accuracy etc.
      train_pred = self.pred_labels[has_label]
      self.train_precision = \
        sklearn.metrics.precision_score(train_labels, train_pred)
      self.train_recall = \
        sklearn.metrics.recall_score(train_labels, train_pred)
      self.train_accuracy = \
        sklearn.metrics.accuracy_score(train_labels, train_pred)

    else:
      # Compute features for all data (for display only).
      # print(self.tb)
      self.ft_matrix = self.feature_pipeline.fit_transform(self.tb, self.user_labels).todense()
      self.ft_names = self.feature_pipeline.get_feature_names()

      self.pred_labels = np.zeros(self.tb.shape[0], dtype=np.float64)
      self.pred_probs = np.zeros(self.tb.shape[0], dtype=np.float64)
      self.pred_margin = np.zeros(self.tb.shape[0], dtype=np.float64)
      self.coefs = np.zeros(len(self.ft_names), dtype=np.float64)
      self.pred_labels[:] = np.NAN
      self.pred_probs[:] = np.NAN
      self.pred_margin[:] = np.NAN
      self.coefs[:] = 0.0
      self.train_precision = 0.0
      self.train_recall = 0.0
      self.train_accuracy = 0.0



if __name__ == "__main__":
  fpc = FeaturePipelineConstructor()
  fpc.add_feature("VISN", "categorical")
  fpc.add_feature("n", "numerical")
  feature_pipeline = fpc.make_pipeline()
  pc = PipelineConstructor()
  pipeline = pc.make_pipeline(feature_pipeline)

  #learner = Learner("../test_data/simulated_data.csv")
  learner = Learner("../../adjudicated_examples/clean/HGB.csv")
  learner.add_bow_features("TestName")
  learner.add_categorical_feature("Units")
  learner.add_numerical_feature("n")
  learner.add_percentile_feature()
  learner.label_example(0, 0)
  learner.label_example(1, 0)
  learner.label_example(2, 0)
  learner.label_example(3, 1)
  learner.update_model()
