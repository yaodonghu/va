import numpy as np
import os
import pandas as pd
import sklearn
import sklearn.model_selection

# Define the raw and clean filenames.
input_examples_dir = "../../adjudicated_examples/raw"
output_examples_dir = "../../adjudicated_examples/clean"
examples = [
  {"fi": "Alanine_Aminotransferase_-_AJZ.csv",              "fo": "ALT_v1.csv"},
  {"fi": "Alanine_Aminotransferase_addendum_-_AJZ.csv",     "fo": "ALT_v2.csv"},
  {"fi": "AlkalinePhosphatase_-_AJZ.csv",                   "fo": "ALP.csv"},
  {"fi": "AspartateAminotransferase_-_AJZ.csv",             "fo": "AST.csv"},
  {"fi": "CA19-9_-_AJZ.csv",                                "fo": "CA19-9.csv"},
  {"fi": "CVDRisk_A1c_Keys_AllVisn_-_AJZ.csv",              "fo": "A1c.csv"},
  {"fi": "CVDRisk_ALT_Keys_AllVisn_-_AJZ.csv",              "fo": "ALT_v3.csv"},
  {"fi": "CVDRisk_Albumin_Keys_AllVisn_-_AJZ.csv",          "fo": "ALB.csv"},
  {"fi": "CVDRisk_HDLC_Keys_AllVisn_-_AJZ.csv",             "fo": "HDLC.csv"},
# {"fi": "Copy_of_Sodium_ResultPctiles_DRG.csv",            "fo": ""},
  {"fi": "Copy_of_Sodium_ResultPctiles_DRG_AJZ.csv",        "fo": "Na.csv"},
  {"fi": "Magnesium_-_ajz.csv",                             "fo": "Mg.csv"},
  {"fi": "Hemoglobin+HGB+DRGv2+LOINC+ck+AJZ+consensus.csv", "fo": "HGB.csv"},
]

# Load the raw tables.
for e in examples:
  e["tb"] = pd.read_csv(os.path.join(input_examples_dir, e["fi"]))

# Remove the following columns from all tables.
globally_excluded_columns = [
   'Quite simple. Exclude any topography matching the substring URINE or the substring FLUID',
   'date of opinion',
   'Exclude topography matching urin, abdom, fluid, dialysate, eye, feces, lung, liver, other, zzzz',
   'Exclude UNLESS Topography matches blood, serum, or plasma. Exclude if LabChemTestName matches pneumo.',
   'AJZ reason',
   'AJZ range 1-99',
   'AJZ comments',
   'Agreement?',
   'agreement',
   '84180150',
   'cumu',
   'ajz comment',
   'concordance',
   'agree?',
   'Agree?',
]
for e in examples:
  for c in globally_excluded_columns:
    if c in e["tb"].columns:
      e["tb"].drop(c, 1, inplace=True)

# Map the following column names to the given ones in all tables.
global_column_renames = {
   "loinc": "LOINC",
   "1st Pctile": "p1",
   "25th Pctile": "p25",
   "50th Pctile": "p50",
   "75th Pctile": "p75",
   "99th Pctile": "p99",
   "Total_Cnt": "n",
   "Min_Result": "min",
   "Max_Result": "max",
}  
for e in examples:
  e["tb"].rename(columns=global_column_renames, inplace=True)

# On a per-table basis, map or remove the following column names.
TRUE_LABEL = "TrueLabel"
REMOVE = 0
per_table_column_renames_or_removes = {
  'Alanine_Aminotransferase_-_AJZ.csv':
    {'AJZ opinion': TRUE_LABEL},
  'Alanine_Aminotransferase_addendum_-_AJZ.csv':
    {'AJZ opinion': TRUE_LABEL},
  'AlkalinePhosphatase_-_AJZ.csv':
    {'AJZ Opinion': TRUE_LABEL},
  'AspartateAminotransferase_-_AJZ.csv':
    {'AJZ Opinion': TRUE_LABEL},
  'CA19-9_-_AJZ.csv':
    {'AJZ Opinion': TRUE_LABEL},
  'CVDRisk_A1c_Keys_AllVisn_-_AJZ.csv':
    {'Yes_No': TRUE_LABEL,
     'Yes_No_AJZ': REMOVE}, # Not sure about this
  'CVDRisk_ALT_Keys_AllVisn_-_AJZ.csv':
    {'Final Yes/No': TRUE_LABEL,
     'DRG Yes/No': REMOVE},
  'CVDRisk_Albumin_Keys_AllVisn_-_AJZ.csv':
    {'DRG Yes_No': REMOVE,
     'AJZ Yes_No': TRUE_LABEL}, # cf Andy's note that "I resolved discrepancies using the AJZ column - use this column as the final result."
  'CVDRisk_HDLC_Keys_AllVisn_-_AJZ.csv':
    {'DRG Yes No': REMOVE,
     'AJZ Yes No': REMOVE,
     'Consensus': TRUE_LABEL},
  'Copy_of_Sodium_ResultPctiles_DRG_AJZ.csv':
    {'Consensus Keep': TRUE_LABEL,
     'DRG keep': REMOVE,
     'AJZ keep': REMOVE},
  'Magnesium_-_ajz.csv':
    {'AJZ Final Decision': TRUE_LABEL,
     'AJZ comment': REMOVE,
     'AJZ auto': REMOVE,
     'AJZ concord': REMOVE,
     'blood': REMOVE,
     'artery': REMOVE,
     'serum': REMOVE,
     'pla': REMOVE,
     'mag': REMOVE,
     'ur': REMOVE},
  'Hemoglobin+HGB+DRGv2+LOINC+ck+AJZ+consensus.csv':
    {'DRG': REMOVE,
     'AJZ': REMOVE,
     'Final Consensus': TRUE_LABEL,
     '_TYPE_': REMOVE,
     '_FREQ_': REMOVE,
     'TopographySID': REMOVE,
     'LOINC_Check': REMOVE}
}
for e in examples:
  renames_or_removes = per_table_column_renames_or_removes[e["fi"]]
  for old_colname, new_colname in renames_or_removes.items():
    if new_colname == REMOVE:
      e["tb"].drop(old_colname, 1, inplace=True)
    else:
      columns = {old_colname: new_colname}
      e["tb"].rename(columns=columns, inplace=True)

# Clean up the true label field.
YES = 1
NO = 0
OTHER = np.NAN
labels_map = {
  'Alanine_Aminotransferase_-_AJZ.csv': {'YES': YES, 'no': NO},
  'Alanine_Aminotransferase_addendum_-_AJZ.csv': {'YES': YES, 'n': NO, 'no': NO},
  'AlkalinePhosphatase_-_AJZ.csv': {'fraction': NO, 'no': NO, 'yes': YES},
  'AspartateAminotransferase_-_AJZ.csv': {'YES': YES, 'no': NO},
  'CA19-9_-_AJZ.csv': {'no': NO, 'yes': YES},
  'CVDRisk_A1c_Keys_AllVisn_-_AJZ.csv': {'N': NO, 'Y': YES},
  'CVDRisk_ALT_Keys_AllVisn_-_AJZ.csv': {'No': NO, 'Yes': YES},
  'CVDRisk_Albumin_Keys_AllVisn_-_AJZ.csv': {'N': NO, 'Y': YES},
  'CVDRisk_HDLC_Keys_AllVisn_-_AJZ.csv': {'No': NO, 'Yes': YES},
  'Copy_of_Sodium_ResultPctiles_DRG_AJZ.csv': {'N': NO, 'Y': YES},
  'Magnesium_-_ajz.csv': {False: NO, True: YES},
  'Hemoglobin+HGB+DRGv2+LOINC+ck+AJZ+consensus.csv': {'No': NO, 'Yes': YES}
}
for e in examples:
  labels_map_for_e = labels_map[e["fi"]]
  #e["tb"]["UncleanedTrueLabel"] = e["tb"][TRUE_LABEL]
  e["tb"][TRUE_LABEL] = e["tb"][TRUE_LABEL].map(labels_map_for_e)

# Check that we don't have any extra unexpected columns, and reorder the column
# names uniformly.
all_possible_columns = ['TrueLabel',

                        'LabChemTestName',
                        'Topography',
                        'Component',
                        'Specimen',

                        'Sta3n',
                        'VISN',
                        'Units',
                        'LOINC',

                        'n',
                        'min',
                        'p1',
                        'p5',
                        'p10',
                        'p25',
                        'p50',
                        'p75',
                        'p90',
                        'p95',
                        'p99',
                        'max',

                        'LabChemTestSID']
for e in examples:
  for c in e["tb"].columns:
    if c not in all_possible_columns:
      assert False, "%s is an unexpected column in %s" % (c, e["fi"])
  existing_ordered_columns = [c for c in all_possible_columns if c in e["tb"].columns]
  e["tb"] = e["tb"].reindex_axis(existing_ordered_columns, axis=1)

# Write the clean tables.
for e in examples:
  e["tb"].to_csv(os.path.join(output_examples_dir, e["fo"]), index=False)

# Print message.
print("Done! The column names are as follows.")
print( [(e["fi"], (e["tb"].columns.tolist())) for e in examples] )
