#import category_encoders
import numpy as np
import os
import pandas as pd
import sklearn
import sklearn.ensemble
import sklearn.feature_extraction
import sklearn.linear_model
import sklearn.model_selection
import sklearn.pipeline

#import lab_learner

class Dataset:
  def __init__(self, filename):
    self.filename = filename
    self.tb = None
    self.true_labels = None
    self.ft = None

# Define the filenames.
data_dir = "../../adjudicated_examples/clean"
data = [
  #Dataset("ALT_v1.csv"), # if require n >= 10, no neg examples
  #Dataset("ALT_v2.csv"), # if require n >= 10, no neg examples
  Dataset("ALP.csv"),
  #Dataset("AST.csv"), # if require n >= 10, no neg examples
  #Dataset("CA19-9.csv"), # if require n >= 10, one class has fewer than 10 examples
  #Dataset("A1c.csv"), # if require n >= 10, one class has fewer than 10 examples
  Dataset("ALT_v3.csv"),
  Dataset("ALB.csv"),
  Dataset("HDLC.csv"),
  Dataset("Na.csv"),
  Dataset("Mg.csv"),
  Dataset("HGB.csv")
]
#data = [Dataset('A1c.csv')]
#data = [Dataset('ALB.csv')]
#data = [Dataset('HDLC.csv')]

# Define the dtype of each column.
dtypes = {'TrueLabel': int,

          'LabChemTestName': str,
          'Topography': str,
          'Component': str,
          'Specimen': str,

          'Sta3n': str,
          'VISN': str,
          'Units': str,
          'LOINC': str,

          'n': np.float64,
          'min': np.float64,
          'p1': np.float64,
          'p5': np.float64,
          'p10': np.float64,
          'p25': np.float64,
          'p50': np.float64,
          'p75': np.float64,
          'p90': np.float64,
          'p95': np.float64,
          'p99': np.float64,
          'max': np.float64,

          'LabChemTestSID': str}

# Load the tables.
for d in data:
  d.tb = pd.read_csv(os.path.join(data_dir, d.filename), dtype=dtypes)
  d.true_labels = d.tb["TrueLabel"]
  d.tb = d.tb.drop("TrueLabel", axis=1)

# Really make sure that the string columns are strings. In particular, map
# np.nan to 'nan'. XXX This is a bit of a hack.
for d in data:
  for column_name, dtype in dtypes.items():
    if dtype == str and column_name in d.tb.columns:
      d.tb[column_name] = [str(x) for x in d.tb[column_name]]

# Exclude examples where n < 10.
for d in data:
  d.true_labels = d.true_labels[d.tb["n"] >= 10]
  d.tb = d.tb.ix[d.tb["n"] >= 10, :]

# Define a class to select the column/columns of the data frame (given to
# transform) that matches the column name/names (given to __init__). This is
# adapted from the sklearn documentation's "Feature Union with Heterogeneous
# Data Sources" example.
class ColumnSelector(sklearn.base.BaseEstimator,
                     sklearn.base.TransformerMixin):
  def __init__(self, column_name_or_names):
    self.column_name_or_names = column_name_or_names
  def fit(self, x, y=None):
    return self
  def transform(self, the_data_frame):
    return the_data_frame.ix[:,self.column_name_or_names]

#   if self.result_type == "Series":
#     return the_data_frame.ix[:,self.column_name]
#   elif self.result_type == "DataFrame":
#     return the_data_frame.ix[:,[self.column_name]]
#   elif self.result_type == "vector":
#     return the_data_frame.ix[:,self.column_name].values
#   elif self.result_type == "matrix":
#     return the_data_frame.ix[:,[self.column_name]].values
#   else:
#     raise AttributeError("Unknown result_type: %s" % self.result_type)

# Define a class to convert the given length-n vector to an n-by-1 matrix,
# which is what sklearn expects.
class ConvertToMatrix(sklearn.base.BaseEstimator,
                      sklearn.base.TransformerMixin):
  def __init__(self):
    pass
  def fit(self, x, y=None):
    return self
  def transform(self, the_column):
    z = np.copy(the_column)
    assert len(z.shape) == 1
    z.shape = (z.shape[0], 1)
    self._feature_names = [the_column.name]
    return z
  def get_feature_names(self):
    return self._feature_names

# Define a version of LabelBinarizer that doesn't collapse the result to a
# vector when the label is binary. This is based on yangjie's answer to
# stackoverflow question 31947140.
class NoCollapseLabelBinarizer(sklearn.preprocessing.LabelBinarizer):
  def transform(self, y):
    Y = super().transform(y)
    if self.y_type_ == "binary":
      print("It's binary:", Y)
      return np.hstack((Y, 1-Y))
    else:
      return Y
  def inverse_transform(self, Y, threshold=None):
    if self.y_type_ == "binary":
      return super().inverse_transform(Y[:,0], threshold)
    else:
      return super().inverse_transform(Y, threshold)

class CategoricalBinarizer(sklearn.base.BaseEstimator,
                           sklearn.base.TransformerMixin):
  def __init__(self):
    pass
  def fit(self, x, y=None):
    self.classes = list(np.unique(x))
    self.classes_dict = {c: i for (i, c) in enumerate(self.classes)}
    return self
  def transform(self, x):
    assert len(x.shape) == 1
    num_examples = x.shape[0]
    num_classes = len(self.classes)
    z = np.zeros((num_examples, num_classes))
    for i in range(num_examples):
      xi = x.values[i]
      if xi in self.classes_dict:
        j = self.classes_dict[xi]
        z[i,j] = 1
    return z
  def get_feature_names(self):
    return self.classes

class BadCategoricalBinarizer(sklearn.base.BaseEstimator,
                           sklearn.base.TransformerMixin):
  def __init__(self):
    self.binarizer = NoCollapseLabelBinarizer()
  def fit(self, x, y=None):
    self.binarizer.fit(x)
    print("In fit, x=", x.values, ", y=", y.values, ", feature_names=", self.get_feature_names())
    return self
  def transform(self, x):
    rv = self.binarizer.transform(x)
    print("In transform, x=", x.values, ", feature_names=", self.get_feature_names())
    print("... rv.shape = ", rv.shape)
    print("... rv = ", rv[range(min(rv.shape[0], 5)),:])
    return rv
  def get_feature_names(self):
    return self.binarizer.classes_

class OldCategoricalBinarizer(sklearn.preprocessing.LabelBinarizer):
  def fit(self, x, y=None):
    return super(CategoricalBinarizer, self).fit(x)
  def get_feature_names(self):
    return self.classes_

# Define a class to convert the given length-n vector of strings to a length-n
# vector of ordinals encoding the categorical variable.
class StringToOrdinalEncoder(sklearn.base.BaseEstimator,
                             sklearn.base.TransformerMixin):
  def __init__(self):
    pass
  def fit(self, x, y=None):
    self.unique_values = np.unique(x)
  def transform(self, x):
    z = np.zeros(len(x))
    z[:] = -1
    for i, u in enumerate(self.unique_values):
      indices_where_x_eq_u = np.where(x == u)[0]
      z[indices_where_x_eq_u] = i
    return z

# Define a class to convert the given vector of strings representing a
# categorical variable to a "one hot" encoding of the categorical variable.
class CategoricalEncoder(sklearn.base.BaseEstimator,
                         sklearn.base.TransformerMixin):
  def __init__(self):
    pass
  def fit(self, x, y=None):
    return self
  def transform(self, the_column):
    z = pd.get_dummies(the_column)
    category_name = the_column.name
    self._feature_names = ["%s=%s" % (category_name, category_value)
                           for category_value in z.columns]
    return z
  def get_feature_names(self):
    return self._feature_names

# Define a class that adds features that compare the distribution of the
# example to the distribution of the "yes" training examples.
class PercentileFeatureEncoder(sklearn.base.BaseEstimator,
                               sklearn.base.TransformerMixin):
  def __init__(self, percentile_column_names):
    self.percentile_column_names = percentile_column_names
  def fit(self, x, y):
    positive_x = x.ix[y == 1,:]
    total_n = np.sum(positive_x["n"])
    weight_vec = positive_x["n"]/total_n
    perct_mat = positive_x.ix[:,self.percentile_column_names].values
    self.positive_percentiles = np.dot(weight_vec, perct_mat)
    return self
  def transform(self, x):
    stats = np.zeros((x.shape[0], 1))
    x_percentiles = x.ix[:,self.percentile_column_names].values
    for i in range(x.shape[0]):
      stats[i,0] = np.max(np.abs(self.positive_percentiles - x_percentiles[i,:]))
    self._feature_names = ["ks_stat"]
    return stats
  def get_feature_names(self):
    return self._feature_names

# Define a class that converts a sparse matrix to a dense one. Our matrices are
# small enough that this is ok.
class ToDense(sklearn.base.BaseEstimator, sklearn.base.TransformerMixin):
  def __init__(self):
    pass
  def fit(self, x, y=None):
    return self
  def transform(self, x):
    return x.todense()

# Define a Pipeline class that has the get_feature_names method. This is from
# pull request #2007 on scikit-learn's github page.
class FeaturePipeline(sklearn.pipeline.Pipeline):
  def get_feature_names(self):
    name, trans = self.steps[-1]
    if not hasattr(trans, 'get_feature_names'):
      raise AttributeError("Transformer %s does not provide"
                           " get_feature_names." % str(name))
    return trans.get_feature_names()

test_results = {}
for d in data:

  # Define column classes.
  percentile_columns = ['p1', 'p5', 'p10', 'p25', 'p50', 'p75', 'p90', 'p95', 'p99']
  column_classes = {
    "bow": ["LabChemTestName", "Topography", "Component", "Specimen"],
    "categorical": ["Sta3n", "VISN", "Units", "LOINC"],
    "numerical": ['n', 'min', 'max'] + percentile_columns,
    "percentile": percentile_columns
  }

  # Exclude columns that don't exist in the data table.
  for class_ in column_classes.keys():
    column_classes[class_] = [c for c in column_classes[class_]
                              if c in d.tb.columns]

  # Define the "bow" (BOW) feature pipeline.
  bow_feature_pipeline = sklearn.pipeline.FeatureUnion(
    transformer_list=[
      (colname, FeaturePipeline([
        ("selector", ColumnSelector(colname)),
        ("bow", sklearn.feature_extraction.text.CountVectorizer())
      ]))
      for colname in column_classes["bow"]
    ])

  # Define the "categorical" (categorical) feature pipeline.
  categorical_feature_pipeline = sklearn.pipeline.FeatureUnion(
    transformer_list=[
      (colname, FeaturePipeline([
        ("selector", ColumnSelector(colname)),
        ("categorical", CategoricalBinarizer()),
        #("ordinal", StringToOrdinalEncoder()),
        #("one_hot", 
        ##("categorical", CategoricalEncoder())
        #("categorical", category_encoders.OneHotEncoder(handle_unknown="ignore"))
      ]))
      for colname in column_classes["categorical"]
    ])

  # Define the "numerical" feature pipeline.
  numerical_feature_pipeline = sklearn.pipeline.FeatureUnion(
    transformer_list=[
      (colname, FeaturePipeline([
        ("selector", ColumnSelector(colname)),
        ("matrix", ConvertToMatrix()),
      ]))
      for colname in column_classes["numerical"]
    ])

  # Define the "numerical" feature pipeline.
  percentile_feature_pipeline = FeaturePipeline([
    ("selector", ColumnSelector(["n"] + column_classes["percentile"])),
    ("percentile", PercentileFeatureEncoder(column_classes["percentile"])),
  ])

  # Define the feature extraction pipeline.
  feature_pipeline = sklearn.pipeline.FeatureUnion(
    transformer_list=[
      ("bow", bow_feature_pipeline),
      ("categorical", categorical_feature_pipeline),
      ("numerical", numerical_feature_pipeline),
      ("percentile", percentile_feature_pipeline)
    ])

  #if d.filename == 'A1c.csv':
  if True:
    the_fit = feature_pipeline.fit(d.tb, d.true_labels)
    the_features = the_fit.transform(d.tb)
    the_imp = sklearn.preprocessing.Imputer()
    the_imp.fit(the_features)
    the_features_imp = the_imp.transform(the_features)
    #print(feature_pipeline.get_feature_names())

  # Define the feature classes of each column.
  pipeline = sklearn.pipeline.Pipeline([
    ('union', feature_pipeline),
    ('imputer', sklearn.preprocessing.Imputer()),
    ('to_dense', ToDense()),
    ('standard', sklearn.preprocessing.StandardScaler()),
    #('lr', sklearn.linear_model.LogisticRegression(penalty="l1", tol=0.01)), # good
    #('lr', sklearn.linear_model.LogisticRegression())
    #('lr', sklearn.svm.SVC())
    ('lr', sklearn.ensemble.RandomForestClassifier()) # good ~97% cv accuracy
    #('lr', sklearn.ensemble.GradientBoostingClassifier()) # good ~97% cv accuracy
    #('lr', sklearn.linear_model.Lasso(normalize=True)) # doesn't work
    #('lr', sklearn.linear_model.LogisticRegressionCV()) # ~89% cv accuracy
    #('lr', sklearn.linear_model.LogisticRegressionCV(penalty="l1", solver="liblinear")) # super slow, doesn't seem much better than LogisticRegression with l1, tol=0.01
  ])
  
  print("\n\n----------------------------\n")
  print("For dataset %s:" % d.filename)

  test_results[d.filename] = {"learning_curve": {}}

  total_num_examples = d.tb.shape[0]
  train_sizes = 2**np.array(range(1, int(np.ceil(np.log2(total_num_examples)))))
  for train_size in train_sizes:
    print("Using %d of %d examples for training:" % (train_size, total_num_examples), end="")

    accuracies = []
    for rep in range(20):
      X_train, X_test, y_train, y_test = \
          sklearn.model_selection.train_test_split(d.tb, d.true_labels,
                                                   train_size=train_size,
                                                   stratify=d.true_labels)
      try:
        pipeline.fit(X_train, y_train)
      except:
        import sys
        print("Failure:", sys.exc_info()[0])
        break
      y_pred = pipeline.predict(X_test)
      accuracies.append(sklearn.metrics.accuracy_score(y_test, y_pred))

    if len(accuracies) > 0:
      print(" with 20 reps, mean accuracy = %f, sd = %f" %
            (np.mean(accuracies), np.std(accuracies)))
      test_results[d.filename]["learning_curve"][train_size] = {
        "accuracies": accuracies,
        "mean_accuracy": np.mean(accuracies),
        "sd_accuracy": np.std(accuracies),
        "se_mean_accuracy": np.std(accuracies)/np.sqrt(20)
      }

    # coefs = pipeline.named_steps['lr'].coef_[0,:]
    # feature_names = pipeline.named_steps['union'].get_feature_names()
    # included_features = []
    # for coef, feature_name in zip(coefs, feature_names):
    #   if coef != 0:
    #     included_features.append((feature_name, coef))
    # included_features.sort(key=lambda x: -x[1])
    # #print(", included_features = %s" % str(included_features))

  #score = sklearn.model_selection.cross_val_score(pipeline, d.tb,
  #                                                d.true_labels, cv=10)
  #print("The 10-fold cross validation accuracy scores are:\n", score)

  predicted = sklearn.model_selection.cross_val_predict(pipeline, d.tb,
                                                        d.true_labels,
                                                        cv=10)
  predicted_accuracy = sklearn.metrics.accuracy_score(d.true_labels,
                                                      predicted)
  print("The overall 10-fold cross validation accuracy is:", predicted_accuracy)
  test_results[d.filename]["ten_fold_cv_accuracy"] = predicted_accuracy

# Then, e.g.:
#import pickle
#fo = open("test_results_rf_v1.pickle", mode="wb"); pickle.dump(test_results, fo); fo.close()
