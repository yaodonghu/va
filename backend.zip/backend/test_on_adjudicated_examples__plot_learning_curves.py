import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pickle

filenames = [("lr", "test_results_lr_with_l1_v1.pickle"),
             ("svm", "test_results_svm_v1.pickle"),
             ("rf", "test_results_rf_v1.pickle")]
results = {m: pickle.load(open(f, "rb")) for (m, f) in filenames}

for method in ["lr", "svm", "rf"]:
  #method = "rf"
  plt.figure()
  plt.axes().set_xscale("log")
  plt.axes().set_ylim(0, 1)
  plt.title("Learning curves for %s method" % method)
  plt.xlabel("Number of training examples")
  plt.ylabel("Accuracy on test set")
  for dataset_name, dataset_results in results[method].items():
    learning_curve = dataset_results["learning_curve"]
    x = list(learning_curve.keys())
    y = [v["mean_accuracy"] for v in learning_curve.values()]
    eb = [v["sd_accuracy"] for v in learning_curve.values()]
    plt.errorbar(x, y, yerr=eb, label=dataset_name, lw=1, alpha=0.8, fmt='o--', capthick=5)
  plt.legend(loc="lower right")
  #plt.show()
  plt.savefig("test_on_adjudicated_examples__plot_learning_curves__%s.png" % method)
