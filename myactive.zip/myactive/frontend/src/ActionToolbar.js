import React from 'react';

export class ActionToolbar extends React.Component {
  render() {
    return (
      <div style={{flex: "0 0 auto"}}>
        <table><tbody><tr><td>
          <table><tbody>
            <AddCategoricalFeatureInput
              columns={this.props.columns}
              onTakeAction={this.props.onTakeAction}
              />
            <AddCountFeatureInput
              columns={this.props.columns}
              onTakeAction={this.props.onTakeAction}
              />
            <AddBOWFeaturesInput
              columns={this.props.columns}
              onTakeAction={this.props.onTakeAction}
              />
          </tbody></table>
        </td>
        <td>
          <table><tbody>
            <RemoveFeatureByNameInput
              onTakeAction={this.props.onTakeAction}
              />
            <RemoveFeaturesByCategoryInput
              categoryNames={this.props.categoryNames}
              onTakeAction={this.props.onTakeAction}
              />
            <RemoveFeaturesBySourceColumnInput 
              columns={this.props.columns}
              onTakeAction={this.props.onTakeAction}
              />
          </tbody></table>
        </td></tr></tbody></table>
      </div>
    )
  }
}

class AddCategoricalFeatureInput extends React.Component {
  constructor(props) {
    super(props);
    this.state = {column: props.columns[0]};
    this._onSelectChange = this._onSelectChange.bind(this);
    this._onSubmit = this._onSubmit.bind(this);
  }

  _onSelectChange(ev) {
    this.setState({column: ev.target.value});
  }

  _onSubmit(ev) {
    this.props.onTakeAction("addCategoricalFeature",
                            {column: this.state.column});
  }

  render() {
    return <tr>
      <td>Add categorical feature</td>
      <td>for column{' '}
        <select value={this.state.column}
                onChange={this._onSelectChange}>
          {this.props.columns.map(column => (
            <option key={column} value={column}>{column}</option>
          ))}
        </select>
      </td>
      <td></td>
      <td>
        <button type="button" onClick={this._onSubmit}>Go</button>
      </td>
    </tr>
  }
}

class AddCountFeatureInput extends React.Component {
  constructor(props) {
    super(props);
    this.state = {column: props.columns[0], pattern: ""};
    this._onSelectChange = this._onSelectChange.bind(this);
    this._onInputChange = this._onInputChange.bind(this);
    this._onSubmit = this._onSubmit.bind(this);
  }

  _onSelectChange(ev) {
    this.setState({column: ev.target.value});
  }

  _onInputChange(ev) {
    this.setState({pattern: ev.target.value});
  }

  _onSubmit(ev) {
    this.props.onTakeAction("addCountFeature",
                            {column: this.state.column,
                             pattern: this.state.pattern});
  }

  render() {
    return <tr>
      <td>Add count feature</td>
      <td>for column{' '}
        <select value={this.state.column}
                onChange={this._onSelectChange}>
          {this.props.columns.map(column => (
            <option key={column} value={column}>{column}</option>
          ))}
        </select>,
      </td>
      <td>pattern
        <input type="text" width="30"
          value={this.state.pattern}
          onChange={this._onInputChange}
        />
      </td>
      <td>
        <button type="button" onClick={this._onSubmit}>Go</button>
      </td>
    </tr>
  }
}

class AddBOWFeaturesInput extends React.Component {
  constructor(props) {
    super(props);
    this.state = {column: props.columns[0]};
    this._onSelectChange = this._onSelectChange.bind(this);
    this._onSubmit = this._onSubmit.bind(this);
  }

  _onSelectChange(ev) {
    this.setState({column: ev.target.value});
  }

  _onSubmit(ev) {
    this.props.onTakeAction("addBOWFeatures",
                            {column: this.state.column});
  }

  render() {
    return <tr>
      <td>Add bag-of-word features</td>
      <td>for column{' '}
        <select value={this.state.column}
                onChange={this._onSelectChange}>
          {this.props.columns.map(column => (
            <option key={column} value={column}>{column}</option>
          ))}
        </select>
      </td>
      <td></td>
      <td>
        <button type="button" onClick={this._onSubmit}>Go</button>
      </td>
    </tr>
  }
}

class RemoveFeatureByNameInput extends React.Component {
  constructor(props) {
    super(props);
    this.state = {featureName: ""};
    this._onInputChange = this._onInputChange.bind(this);
    this._onSubmit = this._onSubmit.bind(this);
  }

  _onInputChange(ev) {
    this.setState({featureName: ev.target.value});
  }

  _onSubmit(ev) {
    this.props.onTakeAction("removeFeatureByName",
                            {featureName: this.state.featureName});
  }

  render() {
    return <tr>
      <td>Remove the feature named{' '}
        <input type="text" width="30"
          value={this.state.featureName}
          onChange={this._onInputChange}
          />
      </td>
      <td>
        <button type="button" onClick={this._onSubmit}>Go</button>
      </td>
    </tr>
  }
}

class RemoveFeaturesByCategoryInput extends React.Component {
  constructor(props) {
    super(props);
    this.state = {categoryName: props.categoryNames[0]};
    this._onSelectChange = this._onSelectChange.bind(this);
    this._onSubmit = this._onSubmit.bind(this);
  }

  _onSelectChange(ev) {
    this.setState({categoryName: ev.target.value});
  }

  _onSubmit(ev) {
    this.props.onTakeAction("removeFeaturesByCategory",
                            {categoryName: this.state.categoryName});
  }

  render() {
    return <tr>
      <td>Remove all features in the category{' '}
        <select value={this.state.categoryName}
                onChange={this._onSelectChange}>
          {this.props.categoryNames.map(categoryName => (
            <option key={categoryName} value={categoryName}>
              {categoryName}
            </option>
          ))}
        </select>
      </td>
      <td>
        <button type="button" onClick={this._onSubmit}>Go</button>
      </td>
    </tr>
  }
}

class RemoveFeaturesBySourceColumnInput extends React.Component {
  constructor(props) {
    super(props);
    this.state = {sourceColumn: props.columns[0]};
    this._onSelectChange = this._onSelectChange.bind(this);
    this._onSubmit = this._onSubmit.bind(this);
  }

  _onSelectChange(ev) {
    this.setState({sourceColumn: ev.target.value});
  }

  _onSubmit(ev) {
    this.props.onTakeAction("removeFeaturesBySourceColumn",
                            {sourceColumn: this.state.sourceColumn});
  }

  render() {
    return <tr>
      <td>Remove all features that originate from column{' '}
        <select value={this.state.sourceColumn}
                onChange={this._onSelectChange}>
          {this.props.columns.map(column => (
            <option key={column} value={column}>{column}</option>
          ))}
        </select>
      </td>
      <td>
        <button type="button" onClick={this._onSubmit}>Go</button>
      </td>
    </tr>
  }
}
