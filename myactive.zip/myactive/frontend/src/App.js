import React from 'react';
//const {Table, Column, Cell} = require('fixed-data-table-2');
import {AutoSizer, Column, Grid, InfiniteLoader, ScrollSync, Table} from 'react-virtualized';
//const Dimensions = require('react-dimensions');
import ContainerDimensions from 'react-container-dimensions';
import request from 'request-json';
import cn from 'classnames';
import {ActionToolbar} from './ActionToolbar.js';
import './App.css';
//import '../node_modules/fixed-data-table-2/dist/fixed-data-table.min.css'
import '../node_modules/react-virtualized/styles.css'; // only needs to be imported once

// Good references:
// - https://css-tricks.com/snippets/css/a-guide-to-flexbox/

class MetaGrid extends React.Component {
  render() {
    return <ScrollSync>
      {({ clientHeight, clientWidth, onScroll, scrollHeight, scrollLeft, scrollTop, scrollWidth }) => (
        <div style={{flex: "1 1 auto",
                     display: "flex",
                     flexDirection: "row",
                     margin: 4}}>
          <div className='PredColumn'
            style={{flex: "0 0 auto",
                    width: 180,
                    overflow: "hidden",
                    border: "0px solid blue"}}>
            <ContainerDimensions>
              {({width, height}) =>
                <NewDataGridWithHeader
                  {...this.props} 
                  tableName="pl"
                  data={this.props.plData}
                  headerData={this.props.plHeaderData}
                  width={width-2}
                  height={height-2}
                  scrollTop={scrollTop}
                  onScroll={onScroll}
                  />
              }
            </ContainerDimensions>
          </div>
          <div className='UserColumn'
            style={{flex: "0 0 auto",
                    width: 75,
                    overflow: "hidden",
                    border: "0px solid blue"}}>
            <ContainerDimensions>
              {({width, height}) =>
                <NewDataGridWithHeader
                  {...this.props} 
                  tableName="ul"
                  data={this.props.ulData}
                  headerData={this.props.ulHeaderData}
                  width={width-2}
                  height={height-2}
                  scrollTop={scrollTop}
                  onScroll={onScroll}
                  valueRenderer={({value, columnIndex, rowIndex}) => (
                    <select value={value} onChange={(e) => {
                      this.props.onClickUserLabel({
                        newLabel: e.target.value,
                        rowIndex: rowIndex
                      });
                    }} style={{width: 50}}>
                      <option value="-">-</option>
                      <option value="yes">yes</option>
                      <option value="no">no</option>
                    </select>
                    // ["yes", "no", "-"].map(v => (
                    //   <a href="#"
                    //     style={{fontWeight: (value == v) ?
                    //                         "bold" : "normal"}}
                    //     onClick={(e) => {
                    //     this.props.onClickUserLabel({
                    //       newLabel: v,
                    //       rowIndex: rowIndex});
                    //     e.preventDefault();
                    //   }}>{v}</a>
                    // ))
                  )} />
              }
            </ContainerDimensions>
          </div>
          <div className='CenterColumn'
            style={{flex: "1 1 auto",
                    border: "0px solid orange"
                    }}>
            <ContainerDimensions>
              {({width, height}) =>
                <NewDataGridWithHeader
                  {...this.props} 
                  tableName="tb"
                  data={this.props.tbData}
                  headerData={this.props.tbHeaderData}
                  width={(this.props.panelDisplay == "both" ||
                          this.props.panelDisplay == "tb") ?
                         width-2 : 0}
                  height={height-2}
                  scrollTop={scrollTop}
                  onScroll={onScroll}
                  />
              }
            </ContainerDimensions>
          </div>
          <div className='RightColumn'
            style={{flex: "1 1 auto",
                    border: "0px solid yellow"}}>
            <ContainerDimensions>
              {({width, height}) =>
                <NewDataGridWithHeader
                  {...this.props}
                  tableName="ft"
                  data={this.props.ftData}
                  headerData={this.props.ftHeaderData}
                  width={(this.props.panelDisplay == "both" ||
                          this.props.panelDisplay == "ft") ?
                         width-2 : 0}
                  height={height-2}
                  scrollTop={scrollTop}
                  onScroll={onScroll}
                  />
              }
            </ContainerDimensions>
          </div>
        </div>
      )}
    </ScrollSync>
  }
}

class BadAddHeader extends React.Component {
  render() {
    return <div>
      {this.props.header}
      {this.props.body}
    </div>
  }
}

class AddHeader extends React.Component {
  render() {
    return <ScrollSync>
      {({ clientHeight, clientWidth, onScroll, scrollHeight, scrollLeft, scrollTop, scrollWidth }) => {
        var mergedOnScroll = this._mergeOnScrolls(this.props.onScroll, onScroll);
        return <div>
          {React.cloneElement(this.props.header, {
            scrollLeft: scrollLeft
           })}
          {React.cloneElement(this.props.body, {
            scrollLeft: scrollLeft,
            onScroll: mergedOnScroll
           })}
        </div>
      }}
    </ScrollSync>
  }

  _mergeOnScrolls(onScroll1, onScroll2) {
    return (function(...args) {
      onScroll1(...args);
      onScroll2(...args);
    });
  }
}

class OldAddHeader extends React.Component {
  render() {
    return <ScrollSync>
      {({ clientHeight, clientWidth, onScroll, scrollHeight, scrollLeft, scrollTop, scrollWidth }) => {
        var mergedOnScroll = this._mergeOnScrolls(this.props.onScroll, onScroll);
        return <div>
          <div>
            {React.cloneElement(this.props.header, {
              scrollLeft: scrollLeft,
              onScroll: mergedOnScroll,
              style: {overflow: "hidden"}
             })}
          </div>
          <div>
            {React.cloneElement(this.props.body, {
              scrollLeft: scrollLeft,
              onScroll: mergedOnScroll
             })}
          </div>
        </div>
      }}
    </ScrollSync>
  }

  _mergeOnScrolls(onScroll1, onScroll2) {
    return (function(...args) {
      onScroll1(...args);
      onScroll2(...args);
    });
  }
}

class HeaderCell extends React.Component {
  render() {
    var sortDir = "-";
    if (this.props.sort.tableName === this.props.tableName &&
        this.props.sort.columnName === this.props.columnName)
      sortDir = this.props.sort.sortDir;

    var sortDisplayValue = "";
    if (sortDir === "asc")
      sortDisplayValue = "↑";
    else if (sortDir === "desc")
      sortDisplayValue = "↓";
    else if (sortDir === "-")
      sortDisplayValue = "";
    else
      console.log(["Unexpected sortDir", sortDir]);

    var coefDisplayValue = "";
    if (this.props.tableName == "ft") {
      var coef = this.props.ftCoefs[this.props.columnName];
      coefDisplayValue = "(" + coef + ")";
    }

    return (
      <a style={{
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            flex: "1"
          }}
          href="#"
          onClick={(e) => {
            e.preventDefault();
            const newSort = (sortDir === "asc") ? "desc" : "asc";
            this.props.onSortChange({
              tableName: this.props.tableName,
              columnName: this.props.columnName,
              sortDir: newSort
            });
          }}>
        {sortDisplayValue}
        {String(this.props.value)}
        &nbsp; {coefDisplayValue}
      </a>
    );
  }
}

class OldHeaderCell extends React.Component {
  constructor(props) {
    super(props)
    this.state = {hover: false};
  }

  render() {
    var hover = this.state.hover;

    var sortDir = "-";
    if (this.props.sort.tableName === this.props.tableName &&
        this.props.sort.columnName === this.props.columnName)
      sortDir = this.props.sort.sortDir;

    var sortDisplayValue = "";
    if (sortDir === "asc")
      sortDisplayValue = "↑";
    else if (sortDir === "desc")
      sortDisplayValue = "↓";
    else if (sortDir === "-")
      sortDisplayValue = "";
    else
      console.log(["Unexpected sortDir", sortDir]);

    return (
      <a style={{
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            flex: "1",
            zIndex: hover ? "1": "auto"
          }}
          href="#"
          onClick={(e) => {
            e.preventDefault();
            const newSort = (sortDir === "asc") ? "desc" : "asc";
            this.props.onSortChange({
              tableName: this.props.tableName,
              columnName: this.props.columnName,
              sortDir: newSort
            });
          }}
          onMouseOver={() => this.setState({hover: true})}
          onMouseOut={() => this.setState({hover: false})}>
        <div style={{
              flex: "0 1 auto",  
              overflow: hover ? "": "hidden",
              backgroundColor: hover ? "#99ff99": ""
            }}>
          {String(this.props.value)}
        </div>
        <div style={{
              flex: "0 0 auto",
              backgroundColor: hover ? "#99ff99": ""
            }}>
          {sortDisplayValue}
        </div>
      </a>
    );
  }
}

// <span style={{transform: "rotate(-45deg)"}}>
class NewDataGridWithHeader extends React.Component {
  // // Make fake data for header by cloning the data object and
  // // replacing each column's values with a single value containing the
  // // column name.
  // _makeHeaderData(data) {
  //   var hd = {
  //     columnNames: data.columnNames,
  //     columnWidths: data.columnWidths,
  //     values: {},
  //     rowCount: data.rowCount
  //   }
  //   hd.columnNames.forEach(columnName => {
  //     return hd.values[columnName] = [columnName];
  //   });
  //   return hd;
  // }

  render() {
    return <AddHeader
      header={
        <NewDataGrid
          {...this.props}
          valueRenderer={({value, columnName}) => (
            <HeaderCell
              tableName={this.props.tableName}
              columnName={columnName}
              sort={this.props.sort}
              value={value}
              ftCoefs={this.props.ftCoefs}
              onSortChange={this.props.onSortChange}
              />
          )}
          data={this.props.headerData}
          height={60}
          rowHeight={60-2}
          cellClassNames="headerCell"
          style={{overflowX: "hidden"}}
          />}
      body={
        <NewDataGrid
          {...this.props}
          data={this.props.data}
          height={this.props.height - 60}
          />}
      onScroll={this.props.onScroll} />
  }
}

class NewDataGrid extends React.Component {
  constructor(props) {
    super(props);
    this._cellRenderer = this._cellRenderer.bind(this);
  }

  render() {
    var data = this.props.data;
    return <Grid
      cellRenderer={this._cellRenderer}
      columnCount={data.columnNames.length}
      columnWidth={({index}) => {
        var columnName = data.columnNames[index];
        var columnWidth = data.columnWidths[columnName];
        return columnWidth;
      }}
      rowCount={data.rowCount}
      rowHeight={this.props.rowHeight}
      height={this.props.height}
      width={this.props.width}
      {...this.props}
    />
  }

  _cellRenderer({
    columnIndex, // Horizontal (column) index of cell
    isScrolling, // The Grid is currently being scrolled
    isVisible,   // This cell is visible within the grid (eg it is not an overscanned cell)
    key,         // Unique key within array of cells
    parent,      // Reference to the parent Grid (instance)
    rowIndex,    // Vertical (row) index of cell
    style        // Style object to be applied to cell (to position it);
                 // This must be passed through to the rendered cell element.
    }) {
      // Get column name and cell value.
      var columnName = this.props.data.columnNames[columnIndex];
      var value = this.props.data.values[columnName][rowIndex];

      // Get class.
      var classNames;
      if ('cellClassNames' in this.props)
        classNames = this.props.cellClassNames;
      else {
        const rowClass = rowIndex % 2 === 0 ? "evenRow" : "oddRow";
        classNames = cn(rowClass, "cell");
      }

	  // Style is required since it specifies how the cell is to be sized and positioned.
	  // React Virtualized depends on this sizing/positioning for proper scrolling behavior.
	  // By default, the grid component provides the following style properties:
	  //    position
	  //    left
	  //    top
	  //    height
	  //    width
	  // You can add additional class names or style properties as you would like.
	  // Key is also required by React to more efficiently manage the array of cells.
	  return (
		<div
          className={classNames}
		  key={key}
		  style={style}
		>
		  {this.props.valueRenderer({
            value: value,
            columnName: columnName,
            columnIndex: columnIndex,
            rowIndex: rowIndex,
            isScrolling: isScrolling,
            isVisible: isVisible})}
		</div>
	  )
  }
}
NewDataGrid.defaultProps = {
  rowHeight: 40,
  valueRenderer: ({value}) => String(value)
};

var example_ft_categoryNames = ["categorical", "regex_count", "word_count"];

class StateHolder extends React.Component {
  constructor(props) {
    super(props);
    var emptyData = {columnNames: [], columnWidths: [], values: [],
                     rowCount: 0};
    this.state = {
      ul: emptyData,
      pl: emptyData,
      tb: emptyData,
      ft: emptyData,
      ulHeader: emptyData,
      plHeader: emptyData,
      tbHeader: emptyData,
      ftHeader: emptyData,
      stats: {trainAccuracy: "-",
              trainPrecision: "-",
              trainRecall: "-"},
      sort: {tableName: "tb",
             columnName: "VISN",
             sortDir: "asc"},
      panelDisplay: "both",
      ftOrder: "index"
    };
    this._client = request.createClient("http://localhost:3000/")
    this._getAndSetState = this._getAndSetState.bind(this);
    this._postAndSetState = this._postAndSetState.bind(this);
    this._onClickUserLabel = this._onClickUserLabel.bind(this);
    this._onTakeAction = this._onTakeAction.bind(this);
    this._onSortChange = this._onSortChange.bind(this);
    this._onPanelDisplayChange = this._onPanelDisplayChange.bind(this);
    this._onFtOrderChange = this._onFtOrderChange.bind(this);
  }

  _getAndSetState(url) {
    this._client.get(url, (err, res, body) => {
      this.setState(body);
    });
  }

  _postAndSetState(url, data) {
    this._client.post(url, data, (err, res, body) => {
      this.setState(body);
    });
  }

  componentDidMount() {
    this._getAndSetState("api/everything");
  }

  _onClickUserLabel({newLabel, rowIndex}) {
    var data = {newLabel: newLabel, rowIndex: rowIndex};
    this._postAndSetState("api/labelExample", data);
  }

  _onTakeAction(actionName, actionData) {
    console.log([actionName, actionData]);
    var url = "api/" + actionName
    this._postAndSetState(url, actionData);
  }

  _onSortChange({tableName, columnName, sortDir}) {
    var data = {
      tableName: tableName,
      columnName: columnName,
      sortDir: sortDir
    };
    this._postAndSetState("api/setSort", data);
  }

  _onPanelDisplayChange(ev) {
    // We use this timeout function to force the dimensions of the
    // grid to reset, or something like that, when one switches back
    // from a feature-only or table-only display to a "both" display.
    var val = ev.target.value;
    this.setState({panelDisplay: "none"},
      () => {
        window.setTimeout(() => {
          this.setState({panelDisplay: val})
        }, 100);
      });
  }

  _onFtOrderChange(ev) {
    this.setState({ftOrder: ev.target.value});
  }

  render() {
    return (
      <div
        style={{display: "flex",
                flexDirection: "column",
                position: "absolute",
                top: 0, left: 0,
                width: "100%",
                height: "100%"}}>
        <ActionToolbar columns={this.state.tb.columnNames}
          categoryNames={example_ft_categoryNames}
          onTakeAction={this._onTakeAction}
          />
        <div style={{display: "flex",
                     flexDirection: "row",
                     margin: 4}}>
          <div style={{flex: "0 0 auto",
                       marginRight: 16}}>
            On training set,
            accuracy is {this.state.stats.trainAccuracy}%,
            precision is {this.state.stats.trainPrecision}%,
            recall is {this.state.stats.trainRecall}%.
          </div>
          <div style={{flex: "0 1 auto",
                       marginRight: 16}}>
            Display:{' '}
            <select value={this.state.panelDisplay}
                    onChange={this._onPanelDisplayChange}>
              <option value="both">Table and features</option>
              <option value="tb">Table only</option>
              <option value="ft">Features only</option>
            </select>
          </div>
          {
          //<div style={{flex: "0 1 auto"}}>
          //  Order features by:{' '}
          //  <select value={this.state.ftOrder}
          //          onChange={this._onFtOrderChange}>
          //    <option value="index">Order added</option>
          //    <option value="coef">Coefficient</option>
          //  </select>
          //</div>
          }
        </div>
        <MetaGrid 
          plData={this.state.pl}
          ulData={this.state.ul}
          tbData={this.state.tb}
          ftData={this.state.ft}
          ftCoefs={this.state.stats.ftCoefs}
          plHeaderData={this.state.plHeader}
          ulHeaderData={this.state.ulHeader}
          tbHeaderData={this.state.tbHeader}
          ftHeaderData={this.state.ftHeader}
          sort={this.state.sort}
          width={400} height={400}
          panelDisplay={this.state.panelDisplay}
          onClickUserLabel={this._onClickUserLabel}
          onSortChange={this._onSortChange}
          />
      </div>
    );
  }
}

class App extends React.Component {
  render() {
    return (
      <div className="App">
        <StateHolder />
        {/* This makes the scrolling happen on the main thread, which keeps
            everything in sync better. Cf.
            https://github.com/bvaughn/react-virtualized/issues/291
        */}
        <canvas style={{position: "absolute", top: 0, width: "100%", height: "100%", pointerEvents: "none"}} />
      </div>
    );
  }
}

export default App;
