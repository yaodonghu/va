import collections
import numpy as np
import pandas as pd

# header = ["DRG", "AJZ", "Final Consensus", "LabChemTestSID", "LabChemTestName",
#           "TopographySID", "Topography", "Specimen", "VISN", "Sta3n", "Units",
#           "_TYPE_", "_FREQ_", "n", "min", "p1", "p5", "p10", "p25", "p50",
#           "p75", "p90", "p95", "p99", "max", "LOINC"]

#header = ["TrueLabel", "LabChemTestSID", "LabChemTestName",
#          "Topography", "Specimen", "VISN", "Sta3n", "Units",
#          "n", "min", "p1", "p5", "p10", "p25", "p50",
#          "p75", "p90", "p95", "p99", "max"]

header = ["TrueLabel", "LabChemTestSID", "LabChemTestName",
          "Units", "LOINC", "Component", "Topography",
          "p1", "p5", "p10", "p25", "p50",
          "p75", "p90", "p95", "p99", "n", "min", "max"]

def log10_randint(low, high, size=1):
  log10_low = np.log10(low)
  log10_high = np.log10(high)
  log10_x = np.random.uniform(log10_low, log10_high, size=size)
  return int(np.round(10**log10_x))

options = [
  {"num_examples": 200,
   "TrueLabel": ["yes"],
   "LabChemTestName": ["height", "ht", "adlt height", "stature"],
   "Topography": ["body", "height", "adult height", "full-body"],
   "Component": ["stadiometer", "digital stadiometer", "height rod", "self-reported"],
   "LOINC": ["6793-4", "1754-1"],
   "Units": {"feet": (np.random.normal, 5.83, 0.33), "ft": (np.random.normal, 5.83, 0.33)},
   "n": (log10_randint, 10, 10000)
  },
  {"num_examples": 200,
   "TrueLabel": ["no"],
   "LabChemTestName": ["length", "infant length"],
   "Topography": ["infant", "body length"],
   "Component": ["stadiometer", "tape", "infant body measurement tape"],
   "LOINC": ["14957-5", "14958-3"],
   "Units": {"cm": (np.random.normal, 50, 3),
             "in": (np.random.normal, 19, 1.5),
             "ft": (np.random.normal, 1.58, 0.125)},
   "n": (log10_randint, 5, 5000)
  },
  {"num_examples": 200,
   "TrueLabel": ["no"],
   "LabChemTestName": ["height", "ht"],
   "Topography": ["body", "height", "full-body"],
   "Component": ["stadiometer", "digital stadiometer", "height rod", "self-reported"],
   "LOINC": ["14957-5", "14958-3"],
   "Units": {"percentile": (np.random.uniform, 0, 100),
             "%": (np.random.uniform, 0, 100),
             "quantile": (np.random.uniform, 0, 1)},
   "n": (log10_randint, 10, 10000)
  }
]

cols = collections.OrderedDict([(k, []) for k in header])

for o in options:
  num_examples = o["num_examples"]

  for k in ["TrueLabel", "LabChemTestName", "Topography", "LOINC", "Component"]:
    cols[k].extend(np.random.choice(o[k], size=num_examples))

  #cols["VISN"].extend(np.random.randint(1, 20+1, size=num_examples))
  #cols["Sta3n"].extend(np.random.randint(1, 1000+1, size=num_examples))

  units = np.random.choice(list(o["Units"].keys()), size=num_examples)
  cols["Units"].extend(units)
  for u in units:
    n_generator = o["n"][0]
    n_generator_params = o["n"][1:]
    n = n_generator(*n_generator_params)
    data_generator = o["Units"][u][0]
    data_generator_params = o["Units"][u][1:]
    data = data_generator(*data_generator_params, size=n)
    cols["n"].append(n)
    cols["min"].append(data.min())
    cols["max"].append(data.max())
    for p in [1, 5, 10, 25, 50, 75, 90, 95, 99]:
      cols["p%d" % p].append(np.percentile(data, p))

cols["LabChemTestSID"] = np.random.permutation(len(cols["TrueLabel"]))

df = pd.DataFrame(cols)
true_label = df.loc[:,["LabChemTestSID", "TrueLabel"]]
true_label.to_csv("simulated_true_labels.csv")
df = df.drop("TrueLabel", 1)
df.to_csv("simulated_data.csv")
