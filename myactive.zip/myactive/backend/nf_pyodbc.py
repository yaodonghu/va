import pyodbc
import getpass

def connect(server, database, uid):
  """Connects to VINCI databases using pyodbc. Three features over pyodbc
  connect: (1) Formats the connect string correctly. (2) Prompts for password
  instead of requiring it to be hardcoded. (3) Sets autocommit and timeout to
  avoid idle session emails from VINCI.

  Example: 
  >>> conn = connect(server="vhacdwrb02", database="CDWWork", uid="vha01\\vhabhsfillmn")
  """
  pwd = getpass.getpass("Password for %s on %s: " % (uid, server))
  conn = pyodbc.connect(";".join(["DRIVER={FreeTDS}",
                                  "SERVER=" + server,
                                  "DATABASE=" + database,
                                  "UID=" + uid,
                                  "PWD=" + pwd,
                                  "TDS_Version=7.4",
                                  "Port=1433"]),
                        autocommit=True, # don't wrap in a transaction
                        timeout=3600) # close connection after 1 hour
  return conn
