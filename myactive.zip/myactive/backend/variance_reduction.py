"""Variance Reduction. This is adapted from
libact/query_strategies/variance_reduction.py"""
import copy
import multiprocessing

import numpy as np
import pandas as pd

from libact.query_strategies._variance_reduction import estVar

import libact

def compute_variance_reduction(model, X, y, **kwargs):
    """Variance Reduction

    This function implements the Variance Reduction active learning algorithm [1]_.
    It is adapted from: libact/query_strategies/variance_reduction.py

    Parameters
    ----------
    model : {libact.model.LogisticRegression instance, 'LogisticRegression'}
        The model used for variance reduction to evaluate the variance.
        Only Logistic regression are supported now.

    sigma : float, >0, optional (default=100.0)
        1/sigma is added to the diagonal of the Fisher information matrix as a
        regularization term.

    optimality : {'trace', 'determinant', 'eigenvalue'},\
            optional (default='trace')
        The type of optimal design.  The options are the trace, determinant, or
        maximum eigenvalue of the inverse Fisher information matrix.
        Only 'trace' are supported now.

    n_jobs : int, optional (default=1)
        The number of processors to estimate the expected variance.

    Attributes
    ----------


    References
    ----------
    .. [1] Schein, Andrew I., and Lyle H. Ungar. "Active learning for logistic
           regression: an evaluation." Machine Learning 68.3 (2007): 235-265.

    .. [2] Settles, Burr. "Active learning literature survey." University of
           Wisconsin, Madison 52.55-66 (2010): 11.
    """
    optimality = kwargs.pop('optimality', 'trace')
    if optimality != "trace":
      raise RuntimeError("Only optimality='trace' is supported now")
    sigma = kwargs.pop('sigma', 1.0)
    n_jobs = kwargs.pop('n_jobs', 1)

    # Extract labelled examples and their labels.
    is_labelled = (~pd.isnull(y))
    Xlabeled = X[is_labelled,:]
    y = y[is_labelled]

    # Extract unlabelled examples.
    Xunlabelled = X[~is_labelled,:]
    X_pool = [Xunlabelled[i,:] for i in range(Xunlabelled.shape[0])]

    # Count the number of unique labels.
    label_count = np.unique(y).shape[0]

    # Initialize an array to store the result.
    statistic = np.zeros(X.shape[0])
    statistic.fill(np.nan)

    # Make a copy of the model and fit it.
    clf = copy.copy(model)
    clf.fit(Xlabeled, y)

    # Set up the arguments to the main calculation.
    args = [(Xlabeled, y, x, clf, label_count, sigma, model) for x in X_pool]

    # Carry out the main calculation.
    if n_jobs >= 2:
      p = multiprocessing.Pool(n_jobs)
      errors = p.map(_E, args)
      p.terminate()
    else:
      errors = list(map(_E, args))

    # Fill in the computed statistic for unlabelled examples.
    statistic[~is_labelled] = errors

    return {"statistic": statistic, "errors": errors, "args": args, "clf": clf}

def _Phi(sigma, PI, X, epi, ex, label_count, feature_count):
    ret = estVar(sigma, PI, X, epi, ex)
    return ret

def _E(args):
    X, y, qx, clf, label_count, sigma, model = args

    sigmoid = lambda x: 1 / (1 + np.exp(-x))
    query_point = sigmoid(_lr_predict_real(clf, [qx]))
    feature_count = len(X[0])
    ret = 0.0
    for i in range(label_count):
        clf_ = copy.copy(model)
        clf_.fit(np.vstack((X, [qx])), np.append(y, i))
        PI = sigmoid(_lr_predict_real(clf_, np.vstack((X, [qx]))))
        ret += query_point[-1][i] * _Phi(sigma, PI[:-1], X, PI[-1], qx,
                                         label_count, feature_count)
    return ret

def _lr_predict_real(model, feature, *args, **kwargs):
    """Call model.decision_function and make its return value more uniform.
    Source: libact/models/logistic_regression.py."""
    dvalue = model.decision_function(feature, *args, **kwargs)
    if len(np.shape(dvalue)) == 1:  # n_classes == 2
        return np.vstack((-dvalue, dvalue)).T
    else:
        return dvalue

if __name__ == "__main__":

    import sklearn.linear_model
    model = sklearn.linear_model.LogisticRegression(penalty="l1", tol=0.01)
    n1 = 10
    n2 = 10
    p = 5
    X1 = np.random.rand(n1, p)
    X2 = np.random.rand(n2, p) + 0.5
    X = np.concatenate([X1, X2], axis=0)
    X[:,0] = np.sin(X[:,0]) # add some structure
    y1 = np.zeros(n1)
    y2 = np.ones(n2)
    y1[[1,3,5]] = np.nan # remove labels
    y2[[1,3,5]] = np.nan # remove labels
    y = np.concatenate([y1, y2])
    kwargs = {}

    res = compute_variance_reduction(model, X, y)
    print(res["statistic"])

    import active
    y_ = [None if np.isnan(yi) else int(yi) for yi in y]
    model_ = libact.models.sklearn_adapter.SklearnProbaAdapter(model)
    dataset = libact.base.dataset.Dataset(X=X, y=y_)
    vr = active.VarianceReduction(dataset, model=model_)
    #vr = libact.query_strategies.variance_reduction.VarianceReduction(dataset, model=model_)
    i = vr.make_query()
    print(i)

    for method in ["lc", "sm", "entropy"]:
      us = libact.query_strategies.uncertainty_sampling.UncertaintySampling(dataset, model=model_, method=method)
      j = us.make_query(return_score=True)
      print(j)
