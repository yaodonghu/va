import argparse
import collections
import itertools
import numpy as np
import os
import pandas as pd
import sklearn.metrics
import nf_pyodbc
pd.set_option("display.width", None) # autodetect width
pd.set_option("display.max_colwidth", 100) # for big table, tmp XXX

# Set up the database connection for rb03.
if "conn_rb03" not in locals():
  conn_rb03 = nf_pyodbc.connect(server="vhacdwrb03", database="CDWWork", uid="vha01\\vhabhsfillmn")
def read_sql(q):
  print(q)
  return pd.read_sql(q, conn_rb03)

def chunk(it, size):
  it = iter(it)
  return iter(lambda: tuple(itertools.islice(it, size)), ())

####

# Define the raw and clean filenames.
input_examples_dir = "../test_data/adjudicated_examples/raw"
output_examples_dir = "../test_data/adjudicated_examples/repulled"
examples = [
  {"fi": "Alanine_Aminotransferase_-_AJZ.csv",              "fo": "ALT_v1.csv"},
  {"fi": "Alanine_Aminotransferase_addendum_-_AJZ.csv",     "fo": "ALT_v2.csv"},
  {"fi": "AlkalinePhosphatase_-_AJZ.csv",                   "fo": "ALP.csv"},
  {"fi": "AspartateAminotransferase_-_AJZ.csv",             "fo": "AST.csv"},
  {"fi": "CA19-9_-_AJZ.csv",                                "fo": "CA19-9.csv"},
  {"fi": "CVDRisk_A1c_Keys_AllVisn_-_AJZ.csv",              "fo": "A1c.csv"},
  {"fi": "CVDRisk_ALT_Keys_AllVisn_-_AJZ.csv",              "fo": "ALT_v3.csv"},
  {"fi": "CVDRisk_Albumin_Keys_AllVisn_-_AJZ.csv",          "fo": "ALB.csv"},
  {"fi": "CVDRisk_HDLC_Keys_AllVisn_-_AJZ.csv",             "fo": "HDLC.csv"},
# {"fi": "Copy_of_Sodium_ResultPctiles_DRG.csv",            "fo": ""},
  {"fi": "Copy_of_Sodium_ResultPctiles_DRG_AJZ.csv",        "fo": "Na.csv"},
  {"fi": "Magnesium_-_ajz.csv",                             "fo": "Mg.csv"},
  {"fi": "Hemoglobin+HGB+DRGv2+LOINC+ck+AJZ+consensus.csv", "fo": "HGB.csv"},
]

# Load the raw tables.
for e in examples:
  e["tb"] = pd.read_csv(os.path.join(input_examples_dir, e["fi"]))

# Build the query's components.

from_and_join = ("from chem.PatientLabChem chem "
                 "left join dim.LabChemTest dim on chem.LabChemTestSID = dim.LabChemTestSID "
                 "left join dim.LOINC l on chem.LOINCSID = l.LOINCSID "
                 "left join dim.Topography t on chem.TopographySID = t.TopographySID ")

basic_columns = ("dim.LabChemTestSID, "
                 "dim.LabChemTestName, "
                 "chem.Units, "
                 "l.LOINC, "
                 "l.Component, "
                 "t.Topography")

basic_columns_pd = ("LabChemTestSID",
                    "LabChemTestName",
                    "Units",
                    "LOINC",
                    "Component",
                    "Topography")

percentiles_desc = [("0.01", "p1"),
                    ("0.05", "p5"),
                    ("0.10", "p10"),
                    ("0.25", "p25"),
                    ("0.50", "p50"),
                    ("0.75", "p75"),
                    ("0.90", "p90"),
                    ("0.95", "p95"),
                    ("0.99", "p99")]
percentiles_list = ["percentile_cont(" + p + ") " +
                    "within group (order by LabChemResultNumericValue) " +
                    "over (partition by " + basic_columns + ") " +
                    "as " + name for p, name in percentiles_desc]
percentiles_columns = ", ".join(percentiles_list)

limits_list = ["count(LabChemResultNumericValue) over (partition by " + basic_columns + ") as n",
               "min(LabChemResultNumericValue) over (partition by " + basic_columns + ") as min",
               "max(LabChemResultNumericValue) over (partition by " + basic_columns + ") as max"]
limits_columns = ", ".join(limits_list)

for ex in examples:
  print("\n\nRepulling", ex["fo"])

  lcts = ex["tb"].LabChemTestSID
  where = " or ".join("(dim.LabChemTestSID = '{}')".format(id) for id in lcts)

  tb = read_sql("select distinct " + basic_columns + ", " + 
                percentiles_columns + ", " +
                limits_columns + " " +
                from_and_join +
                "where " + where)

  tb.to_csv(os.path.join(output_examples_dir, ex["fo"]))
