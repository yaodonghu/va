import argparse
import collections
import itertools
import numpy as np
import os
import pandas as pd
import sklearn.metrics
import sys
import nf_pyodbc
pd.set_option("display.width", None) # autodetect width
pd.set_option("display.max_colwidth", 100) # for big table, tmp XXX

# Set up the database connection for rb03.
if "conn_rb03" not in locals():
  conn_rb03 = nf_pyodbc.connect(server="vhacdwrb03", database="CDWWork", uid="vha01\\vhabhsfillmn")
def read_sql(q):
  print(q)
  return pd.read_sql(q, conn_rb03)

def chunk(it, size):
  it = iter(it)
  return iter(lambda: tuple(itertools.islice(it, size)), ())

####

# Examples:
#argv = ["--output", "./LabChemTestName_like_HGB_or_Hemoglobin.csv",
#        "--LabChemTestName", "%HGB%", "%Hemoglobin%"]
#argv = ["--output", "./beta_2_microglobulin.csv",
#        "--LabChemTestName", "%beta_2_micro%",
#                             "%beta2_micro%",
#                             "%beta_2micro%",
#                             "%beta2micro%",
#                             "%b_2_micro%",
#                             "%b2_micro%",
#                             "%b_2micro%",
#                             "%b2micro%",
#        "--LOINC", "1952-1"]
#argv = ["--output", "./repulled_alb.csv",
#        "--LabChemTestName", "%alb%"]

p = argparse.ArgumentParser()
p.add_argument("--output", required=True)
p.add_argument("--LabChemTestName", nargs="+", default=[])
p.add_argument("--LOINC", nargs="+", default=[])
p.add_argument("--Component", nargs="+", default=[])
p.add_argument("--Topography", nargs="+", default=[])
args = p.parse_args(sys.argv[1:])

# Build the query's components.

where_list = []
for x in args.LabChemTestName:
  where_list.append("dim.LabChemTestName like '{}'".format(x))
for x in args.LOINC:
  where_list.append("l.LOINC like '{}'".format(x))
for x in args.Component:
  where_list.append("l.Component like '{}'".format(x))
for x in args.Topography:
  where_list.append("t.Topography like '{}'".format(x))
where = " or ".join("({})".format(w) for w in where_list)

from_and_join = ("from chem.PatientLabChem chem "
                 "left join dim.LabChemTest dim on chem.LabChemTestSID = dim.LabChemTestSID "
                 "left join dim.LOINC l on chem.LOINCSID = l.LOINCSID "
                 "left join dim.Topography t on chem.TopographySID = t.TopographySID ")

basic_columns = ("dim.LabChemTestSID, "
                 "dim.LabChemTestName, "
                 "chem.Units, "
                 "l.LOINC, "
                 "l.Component, "
                 "t.Topography")

basic_columns_pd = ("LabChemTestSID",
                    "LabChemTestName",
                    "Units",
                    "LOINC",
                    "Component",
                    "Topography")

percentiles_desc = [("0.01", "p1"),
                    ("0.05", "p5"),
                    ("0.10", "p10"),
                    ("0.25", "p25"),
                    ("0.50", "p50"),
                    ("0.75", "p75"),
                    ("0.90", "p90"),
                    ("0.95", "p95"),
                    ("0.99", "p99")]
percentiles_list = ["percentile_cont(" + p + ") " +
                    "within group (order by LabChemResultNumericValue) " +
                    "over (partition by " + basic_columns + ") " +
                    "as " + name for p, name in percentiles_desc]
percentiles_columns = ", ".join(percentiles_list)

limits_list = ["count(LabChemResultNumericValue) over (partition by " + basic_columns + ") as n",
               "min(LabChemResultNumericValue) over (partition by " + basic_columns + ") as min",
               "max(LabChemResultNumericValue) over (partition by " + basic_columns + ") as max"]
limits_columns = ", ".join(limits_list)

tb = read_sql("select distinct " + basic_columns + ", " + 
              percentiles_columns + ", " +
              limits_columns + " " +
              from_and_join +
              "where " + where)

tb.to_csv(args.output)
